package game.gamePlay;

public enum GrowthRate {
	SLOW,MEDIUMSLOW,MEDIUMFAST,FAST;
	
	public static int getNextLevel(int level, GrowthRate g){
		int n = 0;
		switch(g){
		case SLOW:
			n = (int) (5*Math.pow(level, 3)/4.0);
		case MEDIUMSLOW:
			n = (int) ((6.0/5.0)*(Math.pow(level, 3))-(15*level*level)+(100*level)-140);
		case MEDIUMFAST:
			n = (int) (Math.pow(level, 3));
		case FAST:
			n = (int) (4*Math.pow(level, 3)/5.0);
		}
		return n;
	}
	
	public static GrowthRate invert(String s){
		return valueOf(s.toUpperCase());
	}
}
