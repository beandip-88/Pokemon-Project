package engine;

import java.awt.Graphics;

public abstract class Screen {
	private final ScreenFactory screenFactory;
    protected boolean viewUnder;
    protected int position;
	
    public Screen(ScreenFactory screenFactory, boolean viewUnder){
        this.screenFactory = screenFactory;
        this.viewUnder = viewUnder;
    }
    
    public void setPosition(int p){
    	this.position = p;
    }
    
    public abstract void onCreate();
    
    public abstract void onUpdate();
    
    public abstract void onDraw(Graphics g);
    
    public ScreenFactory getScreenFactory(){
        return screenFactory;
    }
    
	public boolean getKey(int k){
		return getScreenFactory().getGame().getKeyboard().getKey(k);
	}
	
	public boolean getKeyConst(int k){
		return getScreenFactory().getGame().getKeyboard().getKeyConst(k);
	}
}
