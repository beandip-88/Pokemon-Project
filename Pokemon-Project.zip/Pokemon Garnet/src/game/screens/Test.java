package game.screens;

import java.awt.Graphics;
import java.awt.event.KeyEvent;

import engine.Screen;
import engine.ScreenFactory;

public class Test extends Screen{
	private boolean allowChange = false;
	private int lastMove;
	public Test(ScreenFactory screenFactory) {
		super(screenFactory, false);
	}

	@Override
	public void onCreate() {
		
	}

	@Override
	public void onUpdate() {
		if(getKey(KeyEvent.VK_UP)){
			
		}else if(getKey(KeyEvent.VK_DOWN)){
			
		}else if(getKey(KeyEvent.VK_RIGHT)){
			
		}else if(getKey(KeyEvent.VK_LEFT)){
			
		}
	}

	@Override
	public void onDraw(Graphics g) {
	}
	
	public boolean getKey(int k){
		return getScreenFactory().getGame().getKeyboard().getKey(k);
	}
}
