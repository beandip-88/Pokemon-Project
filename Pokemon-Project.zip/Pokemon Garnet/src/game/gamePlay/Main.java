package game.gamePlay;

import engine.Game;
import game.screens.World;

public class Main {
	private Game game;
	public static void main(String[] args){
		new Main();
	}
	
	public Main(){
		game = new Game(240,190,"Pokemon Garnet 1.0", 3);
		game.getScreenFactory().showScreen(new World(game.getScreenFactory(),"src\\files\\maps\\Area 1.MAP", game.getPlayer()));
	}
}
