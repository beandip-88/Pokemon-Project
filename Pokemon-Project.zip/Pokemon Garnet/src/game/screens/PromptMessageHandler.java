package game.screens;

import java.awt.Graphics;

import engine.Screen;
import engine.ScreenFactory;

public class PromptMessageHandler{
	private PromptMessage prompt;
	private ScreenFactory sc;
	private int finalAnswer = -1;
	public PromptMessageHandler(ScreenFactory sf, String question, String[] choices){
		prompt = new PromptMessage(sf,question, choices, 170, 70);
		prompt.onCreate();
		this.sc = sf;
	}
	
	public void update(){
		prompt.onUpdate();
		if(prompt.hasAnswered()){
			finalAnswer = prompt.getAnswer();
			sc.pop();
		}
	}
	
	public int getAnswer(){
		return finalAnswer;
	}
	
	public void draw(Graphics g){
		prompt.onDraw(g);
	}
}
