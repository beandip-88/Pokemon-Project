package game.gamePlay;

public class IV {
	private int IV;
	
	public IV(int i){
		this.IV = i;
	}
	
	public IV(){
		this.IV = (int) (Math.random()*32);
	}
	
	public int[] toBinary(){
		int[] temp = new int[6];
		for(int a = 0; a < 6; a ++){
			if((this.IV & (1 << a)) != 0){
				temp[a] = 1;
			}else{
				temp[a] = 0;
			}
			System.out.println(temp[a]);
		}
		return temp;
	}
	
	public int getIV(){
		return IV;
	}
}
