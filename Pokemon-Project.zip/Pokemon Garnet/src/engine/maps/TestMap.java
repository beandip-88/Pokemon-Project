package engine.maps;

import engine.Game;
import engine.PositionEvent;
import game.gamePlay.TextType;
import game.screens.Speech;

public class TestMap extends Map{
	private int stepNumber;
	public TestMap(String path, Game game) {
		super(path, game);
		stepNumber = game.getEventHandler().addEvent(new PositionEvent(5,5));
	}

	@Override
	public void mapScript() {
		if(game.getEventHandler().getEvent(stepNumber).check()){
			game.getScreenFactory().showScreen(new Speech(game.getScreenFactory(),"HEYY You found me!",TextType.GREY));
		}
	}
	
}
