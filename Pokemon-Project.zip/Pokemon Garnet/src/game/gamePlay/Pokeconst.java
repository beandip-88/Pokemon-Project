package game.gamePlay;

import engine.Point;

public class Pokeconst {
	private Point startingPoint;
	private String name;
	private int id;
	PokeType a,b;
	private int attack;
	private int defence;
	private int spDef;
	private int spAtt;
	private int speed;
	private int health;
	private GrowthRate g;
	private int xpFactor;
	private int[] evVals;
	
	public Pokeconst(String name, int id, String[] poke, int[] stats, String g, int xp, int[] ev, int x, int y){
		this.startingPoint = new Point(x,y);
		this.health = stats[0];
		this.attack = stats[1];
		this.defence = stats[2];
		this.spAtt = stats[3];
		this.spDef = stats[4];
		this.speed = stats[5];
		this.id = id;
		this.name = name;
		this.xpFactor = xp;
		this.a = PokeType.invert(poke[0]);
		this.b = PokeType.invert(poke[1]);
		this.g = GrowthRate.invert(g);
		this.evVals = ev;
	}
	
	public int getHealth(){
		return health;
	}
	
	public int getAttack(){
		return attack;
	}
	
	public int getDefence(){
		return defence;
	}
	
	public int getSpDef(){
		return spDef;
	}
	
	public int getSpAtt(){
		return spAtt;
	}
	
	public int getSpeed(){
		return speed;
	}
	
	public String getName(){
		return name;
	}
	
	public int getID(){
		return id;
	}
	
	public int getXP(){
		return xpFactor;
	}
	
	public GrowthRate getGrowthRate(){
		return g;
	}
	
	public PokeType getTypeA(){
		return a;
	}
	
	public PokeType getTypeB(){
		return b;
	}
	
	public int getHealthEV(){
		return evVals[0];
	}
	
	public int getAttackEV(){
		return evVals[1];
	}
	
	public int getDefenceEV(){
		return evVals[2];
	}
	
	public int getSpAttEV(){
		return evVals[3];
	}
	
	public int getSpDefEV(){
		return evVals[4];
	}
	
	public int getSpeedEV(){
		return evVals[5];
	}
	
	public int getEV(int x){
		return evVals[x];
	}
	
	public int getStat(int x){
		switch(x){
		case 0:
			return health;
		case 1:
			return attack;
		case 2:
			return defence;
		case 3:
			return spAtt;
		case 4:
			return spDef;
		case 5:
			return speed;
		}
		return -1;
	}
	
	public Point getPoint(){
		return startingPoint;
	}
}
