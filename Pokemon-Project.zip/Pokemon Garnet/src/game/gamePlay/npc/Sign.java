package game.gamePlay.npc;

import engine.Point;

public class Sign extends NPC{
	private String toSay;
	public Sign(String toSay){
		super(false);
		this.toSay = toSay;
		this.updatable = false;
		this.drawable = false;
	}
	
	@Override
	public String onInterract(Direction from) {
		return toSay;
	}
	
	public Point[] areaTaken(){
		return new Point[]{new Point((int)getX(),(int)getY())};
	}
}
