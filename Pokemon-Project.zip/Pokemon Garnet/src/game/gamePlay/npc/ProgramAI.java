package game.gamePlay.npc;

import java.util.ArrayList;

import engine.maps.Map;

public class ProgramAI extends NPCAI{
	
	private AIString string;
	private int arrPos = 0;
	
	public ProgramAI(AIString string){
		super();
		this.string = string;
	}
	
	public void onTick(boolean[][] spacement, ArrayList<Integer> list, int index, Map map, NPC npc) {
		if(npc.updating){return;}
		boolean completed = false;
		boolean b = false;
		if(list.get(index).intValue()<20){return;}
		if(list.get(index).intValue()>=20){
			b = true;
		}
		switch(string.getCommands()[arrPos].getDirection()){
		case UP:
			completed = npc.up(npc,spacement,list.get(index),map);
			break;
		case DOWN:
			completed = npc.down(npc,spacement,list.get(index),map);
			break;
		case LEFT:
			completed = npc.left(npc,spacement,list.get(index),map);
			break;
		case RIGHT:
			completed = npc.right(npc,spacement,list.get(index),map);
			break;
		default:
			break;
		}
		if(completed){
			arrPos++;
		}
		if(arrPos>=string.getCommands().length){
			arrPos = 0;
		}
		npc.setUpdating(true);
		if(b){
			map.getTimers().set(index, 0);
		}
	}

}
