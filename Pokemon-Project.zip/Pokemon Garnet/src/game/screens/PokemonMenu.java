package game.screens;

import java.awt.Graphics;
import java.awt.event.KeyEvent;

import engine.Game;
import engine.Point;
import engine.Screen;
import engine.ScreenFactory;
import game.gamePlay.PokeSprite;
import game.gamePlay.TextType;
import game.gamePlay.imgs.Img;

public class PokemonMenu extends Screen{
	private final String sheet = "src\\files\\images\\Pokemon Menu.png";
	private final Img baseScreen = new Img(new Point(250,5), new Point(489,164), sheet);
	private int selector = 0;
	private int xOffset = 0;
	private final TextType font = TextType.GREY;
	public PokemonMenu(ScreenFactory screenFactory) {
		super(screenFactory, false);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onUpdate() {
		if(getKey(KeyEvent.VK_B)){
			getScreenFactory().pop();
		}else if(getKey(KeyEvent.VK_UP)){
			selector++;
			selector%=7;
		}else if(getKey(KeyEvent.VK_DOWN)){
			selector--;
			selector%=7;
		}
	}

	@Override
	public void onDraw(Graphics g) {
		// TODO Auto-generated method stub
		baseScreen.drawBase(g, 0, 0, .994, 1.13); // It was off by a little and it bugged me. Deal with it
	}
	
	
	public void drawPokemonAt(Graphics g, int id, int x, int y, PokeSprite p){
		PokeSprite.getImg(p, getScreenFactory().getGame().getPlayer().getPokemon(id-1)).drawBase(g, x, y);
	}
	
	public synchronized void drawItems(Graphics g, int start, int end, int yVal, String s){
		int xVal = xOffset*Game.multiplier;
		Img temp = null;
		for(int a = start; a < end; a++){
			temp = font.getCharacter(s.substring(a,a+1));
			temp.drawBase(g, xVal, yVal);
			xVal+=temp.getPx()*Game.multiplier;
		}
	}
}
