package game.gamePlay.npc;

import engine.Point;

public class GeneralNPC extends NPC {
	private String toSay;
	private String name;
	private Point startingPoint;
	public GeneralNPC(String toSay, NPC n, String name, Point p){
		super(n,9,false, true);
		this.toSay = toSay;
		this.name = name;
		super.setStartingPoint(p);
	}
	
	public GeneralNPC(String toSay){
		super(true);
		this.toSay = toSay;
	}
	
	@Override
	public String onInterract(Direction from) {
		this.setDir(Direction.opposite(from), true, false, false);
		return name+ ": "+toSay;
	}
	


}
