package game.gamePlay.npc;

import java.util.ArrayList;

import engine.maps.Map;
import engine.Point;


/**
 * 
 * @author superbeandip
 * PREFACE:
 * This class was previously buggy where the AI would distance outside the radius without checking, then get stuck resulting in an
 * infinite loop. This bug was never 'solved' but I just made the AI update slower and added a timer system (that doesn't really
 * do anyting) but the AI was able to run for over 10 minutes without error (which I ended it because I got bored).
 */
public class RandomPath extends NPCAI{
	protected double radius;
	public RandomPath(double rad){
		super();
		this.radius = rad;
	}

	public void onTick(boolean[][] spacement, ArrayList<Integer> list, int index, Map map, NPC npc) {
		if(npc.updating()){return;}
		int temp = (int)(Math.random()*100); // this number changes the frequency of moving (larger == lower frequency)
		Point dest = null;
		if(temp == 1){
			int dir = (int)(Math.random()*4);
			switch(dir){
			case 0:
				dest = npc.getNextStep(Direction.NORTH);
				break;
			case 1:
				dest = npc.getNextStep(Direction.EAST);
				break;
			case 2:
				dest = npc.getNextStep(Direction.SOUTH);
				break;
			default:
				dest = npc.getNextStep(Direction.WEST);
				break;
			}
			int dirc = 0;
			while(dest.distance(new Point(npc.getStartingPoint().getX(),npc.getStartingPoint().getY()))>radius){
				dir = (dir+1)%4;
				dirc++;
				switch(dir){
				case 0:
					dest = new Point((int)npc.getX(),(int)npc.getY()-1);
					break;
				case 1:
					dest = new Point((int)npc.getX()-1,(int)npc.getY());
					break;
				case 2:
					dest = new Point((int)npc.getX(),(int)npc.getY()+1);
					break;
				default:
					dest = new Point((int)npc.getX()+1,(int)npc.getY());
					break;
				}
				if(dest.distance(new Point((int)npc.getStartingPoint().getX(),(int)npc.getStartingPoint().getY()))<=radius){
					break;
				}
				if(dirc >= 4){
					if(npc.getStartingPoint().getX() > npc.getX()){
						npc.right(npc,spacement,list.get(index),map);
						break;
					}else if(npc.getStartingPoint().getX() < npc.getX()){
						npc.left(npc,spacement,list.get(index),map);
						break;
					}
					if(npc.getStartingPoint().getY() > npc.getY()){
						npc.down(npc,spacement,list.get(index),map);
						break;
					}else if(npc.getStartingPoint().getY() < npc.getY()){
						npc.up(npc,spacement,list.get(index),map);
						break;
					}	
				}
			}
			boolean b = false;
			if(list.get(index).intValue()>=20){
				b = true;
			}
			switch(dir){
			case 0:
				if(npc.getStartingPoint().distance(npc.getNextStep(Direction.NORTH))<=radius){
					npc.up(npc,spacement,list.get(index),map);
				}
				break;
			case 1:
				if(npc.getStartingPoint().distance(npc.getNextStep(Direction.WEST))<=radius){
					npc.left(npc,spacement,list.get(index),map);
				}
				break;
			case 2:
				if(npc.getStartingPoint().distance(npc.getNextStep(Direction.SOUTH))<=radius){
					npc.down(npc,spacement,list.get(index),map);
				}
				break;
			default:
				if(npc.getStartingPoint().distance(npc.getNextStep(Direction.EAST))<=radius){
					npc.right(npc,spacement,list.get(index),map);
				}
				break;
			}
			npc.setUpdating(true);
			if(b){
				map.getTimers().set(index, 0);
			}
		}
	}
}
