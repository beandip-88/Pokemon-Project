package game.gamePlay.playerInfo;

import game.gamePlay.playerInfo.items.*;

public class PlayerItem {
	private Item item;
	private int quantity;
}
