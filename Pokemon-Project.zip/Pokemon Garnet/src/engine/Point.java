package engine;

public class Point {
	private int x;
	private int y;
	public Point(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	public String toString(){
		return x+", "+y;
	}
	
	public boolean equals(Point p){
		return (this.x == p.getX() && this.y == p.getY());
	}
	
	public Point plus(Point p){
		return new Point(p.getX()+this.x,p.getY()+this.y);
	}
	
	public double distance(Point p){
		return Math.sqrt(Math.pow(this.y - p.getY(), 2)+Math.pow(this.x - p.getX(), 2));
	}
}
