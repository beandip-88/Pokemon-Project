package engine;

import java.awt.Graphics;
import java.awt.RenderingHints;
import java.util.ArrayList;
import javax.swing.JPanel;

import game.screens.PromptMessage;

public class GameThread extends JPanel implements Runnable{
    private final Game game;
    public boolean running;
    private int ticky;
    public GameThread(Game game){
        this.game = game;
        setFocusable(true);
        this.ticky = 0;
        start();
    }

    @Override
    public void run(){
        long lastTime = System.nanoTime();
        double nsPerTick = 1000000000.0/60.0;
        int frames = 0, ticks = 0;
        long lastTimer = System.currentTimeMillis();
        double delta = 0;
        boolean shouldRender;
        long now;
        int line = 0;
        while(running){
            now = System.nanoTime();
            delta+=(now-lastTime)/nsPerTick;
            lastTime = now;
            shouldRender = false;
            while(delta>=1){
                ticks++;
                ticky = ticks;
                if(game.getScreenFactory().getCurrentScreen()!=null){
                    game.getScreenFactory().getCurrentScreen().onUpdate();
                }
                delta-=1;
                shouldRender = true;
            }
            try{
                Thread.sleep(2);
            }catch(Exception e){

            }
            if(shouldRender){
                frames++;
                repaint();
            }
            if(System.currentTimeMillis()-lastTimer>=1000){
                lastTimer+=1000;
                line++;
                frames=0;
                ticks=0;
            }
        }
    }

    public synchronized void stop(){
        running = false;
    }
    
    public int getTicks(){
        return ticky;
    }

    public synchronized void start(){
        running = true;
        new Thread(this).start();
    }

    public void paint(Graphics g){
        super.paint(g);
        if(game.getScreenFactory().getCurrentScreen()!=null){
        		game.getScreenFactory().getCurrentScreen().onDraw(g);
        }
    }
}