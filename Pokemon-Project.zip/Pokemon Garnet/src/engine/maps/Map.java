package engine.maps;

import java.util.ArrayList;
import java.util.HashMap;

import engine.Game;
import engine.MapInfo;
import engine.MapLoader;
import engine.Point;
import engine.ScreenFactory;
import engine.SuperTile;
import game.gamePlay.npc.NPC;

public abstract class Map {
	protected Game game;
	private MapInfo myMap;
	private String path;
	private ArrayList<Point> points = new ArrayList<Point>();
	private ArrayList<NPC> npcs = new ArrayList<NPC>();
	private ArrayList<Integer> npcTimers = new ArrayList<Integer>();
	private HashMap<Point,String> teleports = new HashMap<Point,String>();
	public Map(String path, Game game){
		this.path = path;
		this.game = game;
	}
	
	public MapInfo getMapInfo(){
		return myMap;
	}
	
	public int height(){
		return myMap.getHeight();
	}
	
	public int width(){
		return myMap.getWidth();
	}
	
	public NPC getNPC(int p){
		return npcs.get(p);
	}
	
	public Point getPoint(int p){
		return points.get(p);
	}
	
	public String getStringAt(int a, int b){
		return myMap.getStringAt(a, b);
	}
	
	public SuperTile getTileAt(int a, int b){
		return myMap.getTileAt(a, b);
	}
	
	public void setTileAt(int a, int b, SuperTile t){
		myMap.setTileAt(a, b, t);
	}
	
	public void add(Point p,NPC n){
		System.out.println(pointLen());
		npcs.add(n);
		points.add(p);
		n.setCoord(p.getX(), p.getY());
		System.out.println(n.getX());
		npcTimers.add(0);
	}
	
	public ArrayList<Integer> getTimers(){
		return npcTimers;
	}
	
	public void setMap(MapInfo i){
		this.myMap = i;
	}
	
	public int getIndex(Point p){
		for(int a = 0; a < points.size(); a++){
			if(points.get(a).getX() == p.getX() && points.get(a).getY() == p.getY()){
				return a;
			}
		}
		return -1;
	}
	
	public int indexOf(NPC n){
		return points.indexOf(n);
	}
	
	public int pointLen(){
		return points.size();
	}
	
	public int NPCLen(){
		return npcs.size();
	}
	
	public ArrayList<Point> getPoints(){
		return points;
	}
	
	public void setPoint(int index,Point p){
		points.remove(index);
		points.add(index,p);
	}
	
	public void init(ScreenFactory sf){
		MapLoader ml = new MapLoader(path);
		this.myMap = ml.getMap();
		System.out.println(myMap.getStringAt(0,0));
		for(int a = 0; a< myMap.aLen(); a++){
			for(int b = 0; b < myMap.bLen(a); b++){
				sf.getGame().getTiles().addTile(myMap.getStringAt(a,b));
			}
		}
		myMap.init();
	}
	
	public abstract void mapScript();
}
