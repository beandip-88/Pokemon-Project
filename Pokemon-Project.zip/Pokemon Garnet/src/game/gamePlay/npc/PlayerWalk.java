package game.gamePlay.npc;

public class PlayerWalk extends NPC {
	
	public PlayerWalk() {
		super(3, 9, true, true);
	}

	@Override
	public String onInterract(Direction from) {
		return null;
	}
	
	public String toString(){
		return "player walk";
	}
}
