package game.gamePlay.status;

import game.gamePlay.Pokemon;
import game.gamePlay.move.Move;

public class NoStatus extends StatusEffect {

	@Override
	public void onAttack(Move m, Pokemon user, Pokemon target) {
		m.useMove(user, target);
	}

	@Override
	public void onNextMove() {
		// Nothing happens b/c there is no effect
	}

}
