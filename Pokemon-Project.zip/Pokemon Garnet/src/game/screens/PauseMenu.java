package game.screens;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import engine.Game;
import engine.Screen;
import engine.ScreenFactory;
import game.gamePlay.FrameType;
import game.gamePlay.Settings;
import game.gamePlay.TextType;
import game.gamePlay.imgs.Img;

public class PauseMenu extends Screen {
	// Constants from settings
	private final TextType font = TextType.GREY;
	private final FrameType frame = Settings.FRAME;
	private final ArrayList<String> items = Settings.pauseItems;
	// Variables for display (determined on create)
	private int x = 160*Game.multiplier;
	private int y = 10*Game.multiplier;
	private int endX = 235*Game.multiplier;
	private int endY;
	private int select = 0;
	private int num;
	// Simple display array
	private final int[] yArgs = new int[]{21,39,57,75,93,111,129};
	private final int xOffset = 177;
	public PauseMenu(ScreenFactory screenFactory) {
		super(screenFactory, true);
	}

	@Override
	public void onCreate() {
		if(items.size()==5){
			endY = y + 108*Game.multiplier;
			num = 12;
		}else if(items.size()==6){
			endY = y + 126*Game.multiplier;
			num = 14;
		}else{
			endY = y + 144*Game.multiplier;
			num = 16;
		}
	}

	@Override
	public void onUpdate() {
		if(getKey(KeyEvent.VK_UP)){
			select--;
			if(select<0){
				select=items.size()-1;
			}
		}else if(getKey(KeyEvent.VK_DOWN)){
			select++;
			if(select>=items.size()){
				select = 0;
			}
		}else if(getKey(KeyEvent.VK_A)){
			if(select ==  items.size()-1){
				getScreenFactory().pop();
			}else if(select == items.size()-2){
				getScreenFactory().showScreen(new OptionMenu(getScreenFactory()));
			}else if(select == items.size()-3){
				getScreenFactory().showScreen(new SaveMenu(getScreenFactory()));
			}else if(select == items.size()-4){
				getScreenFactory().showScreen(new PlayerCard(getScreenFactory()));
			}else if(select == items.size()-5){
				getScreenFactory().showScreen(new Bag(getScreenFactory()));
			}else if(select == items.size()-6){
				getScreenFactory().showScreen(new PokemonMenu(getScreenFactory()));
			}else{
				getScreenFactory().showScreen(new Pokedex(getScreenFactory()));
			}
		}else if(getKey(KeyEvent.VK_B)||getKey(KeyEvent.VK_ENTER)){
			getScreenFactory().pop();
		}
	}

	@Override
	public void onDraw(Graphics g) {
		if(this.viewUnder){
			if(this.position != 0){
				getScreenFactory().getScreenFromTop(this.position-1).onDraw(g);
			}
		}
		g.setColor(font.getColor());
		g.fillRect(x+4*Game.multiplier, y+4*Game.multiplier, endX-x-7*Game.multiplier, endY-y-7*Game.multiplier);
		frame.getImg("Right").drawVert(g, endX-8*Game.multiplier, y+8*Game.multiplier, num);
		frame.getImg("Left").drawVert(g, x, y+8*Game.multiplier,  num);
		frame.getImg("Top").drawHor(g, x+8*Game.multiplier, y, 8);
		frame.getImg("Bottom").drawHor(g, x+8*Game.multiplier, endY-8*Game.multiplier, 8);
		frame.getImg("UpperLeft").drawBase(g, x, y);
		frame.getImg("UpperRight").drawBase(g, (endX-8*Game.multiplier), y);
		frame.getImg("LowerRight").drawBase(g, (endX-8*Game.multiplier), (endY-8*Game.multiplier));
		frame.getImg("LowerLeft").drawBase(g, x, (endY-8*Game.multiplier));
		for(int a = 0; a < items.size(); a++){
			drawItems(g, 0, items.get(a).length(), yArgs[a]*Game.multiplier, items.get(a));
		}
		font.getCharacter("\\ARROW\\").drawBase(g, (xOffset-7)*Game.multiplier, (yArgs[select%items.size()]+1)*Game.multiplier);
	}
	
	public synchronized void drawItems(Graphics g, int start, int end, int yVal, String s){
		int xVal = xOffset*Game.multiplier;
		Img temp = null;
		for(int a = start; a < end; a++){
			temp = font.getCharacter(s.substring(a,a+1));
			temp.drawBase(g, xVal, yVal);
			xVal+=temp.getPx()*Game.multiplier;
		}
	}

}
