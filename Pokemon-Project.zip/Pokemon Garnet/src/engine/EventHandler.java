package engine;

import java.util.ArrayList;
import java.util.HashMap;

public class EventHandler {
	private int hashPos = 0;
	private ArrayList<Event> events = new ArrayList<Event>();
	private Game g;
	
	public EventHandler(Game g){
		this.g = g;
	}
	
	public int addEvent(Event e){
		events.add(e);
		hashPos++;
		return hashPos-1;
	}
	
	public Event getEvent(int pos){
		return events.get(pos);
	}
	
	public void clear(){
		for(int a = 0; a < events.size(); a++){
			events.remove(a);
		}
	}
	
	public void update(){
		for(int a = 0; a < events.size(); a++){
			events.get(a).setOccurance(events.get(a).check());
		}
	}
	
	public void remove(int index){
		events.remove(index);
	}
}
