package game.gamePlay;

import java.awt.Color;
import java.util.HashMap;

import engine.Point;
import game.gamePlay.imgs.Img;

public enum TextType {
	WHITE, GREY, DBLUE, DRED, LBLUE, PINK, LRED;
	
	private final String sheet = "src\\files\\images\\Fonts.PNG";
	private final Color[] bg = new Color[]{Color.black,Color.white,Color.white,Color.white,Color.white,Color.white,Color.white};
	private final Point[] vectors = new Point[]{new Point(0,0),new Point(-262,0),new Point(0,-189),new Point(-262,-189),new Point(0,-288),new Point(-262,-288),new Point(0,-381)};
	
	public Point getVector(TextType t){
		return vectors[t.toInt()];
	}
	
	@SuppressWarnings({"serial"})
	private HashMap<String, Img> chars = new HashMap<String,Img>(){{
		put("\\|^\\",new Img(new Point(0,43),new Point(9,56), sheet));  // 2 above arrow should be 43 from P[o]
		put("\\|v\\",new Img(new Point(12,43),new Point(21,56), sheet));
		put("\\<-\\",new Img(new Point(24,43),new Point(32,56), sheet));
		put("\\->\\",new Img(new Point(37,43),new Point(45,56), sheet));
		put("\\pkmn\\",new Img(new Point(117,29),new Point(132,42), sheet));
		put("\\poke\\",new Img(new Point(133,29),new Point(148,42), sheet));
		put("\\block\\",new Img(new Point(149,29),new Point(168,42), sheet));
		put("\\Lv\\",new Img(new Point(75,29),new Point(84,42), sheet));
		put(";",new Img(new Point(113,29),new Point(114,42), sheet));
		put("\\!\\",new Img(new Point(105,29),new Point(110,42), sheet));
		put("\\re\\",new Img(new Point(64,43),new Point(71,56), sheet));
		put("\\[m]\\",new Img(new Point(24,57),new Point(29,70), sheet));
		put("\\[f]\\",new Img(new Point(30,57),new Point(35,70), sheet));
		put("\\$\\",new Img(new Point(37,57),new Point(42,70), sheet));
		put("&",new Img(new Point(60,29),new Point(66,42), sheet));
		put("+",new Img(new Point(68,29),new Point(74,42), sheet));
		put("=",new Img(new Point(87,29),new Point(93,42), sheet));
		put(":",new Img(new Point(95,29),new Point(98,42), sheet));
		put("\\?\\",new Img(new Point(99,29),new Point(103,42), sheet));
		put("%",new Img(new Point(169,29),new Point(177,42), sheet));
		put("(",new Img(new Point(178,29),new Point(181,42), sheet));
		put(")",new Img(new Point(183,29),new Point(186,42), sheet));
		put("<",new Img(new Point(49,43),new Point(55,56), sheet));
		put(">",new Img(new Point(57,43),new Point(63,56), sheet));
		put("0",new Img(new Point(72,43),new Point(77,56), sheet));
		put("1",new Img(new Point(79,43),new Point(82,56), sheet));
		put("2",new Img(new Point(84,43),new Point(89,56), sheet));
		put("3",new Img(new Point(90,43),new Point(95,56), sheet));
		put("4",new Img(new Point(96,43),new Point(101,56), sheet));
		put("5",new Img(new Point(102,43),new Point(107,56), sheet));
		put("6",new Img(new Point(108,43),new Point(113,56), sheet));
		put("7",new Img(new Point(114,43),new Point(119,56), sheet));
		put("8",new Img(new Point(120,43),new Point(125,56), sheet));
		put("9",new Img(new Point(126,43),new Point(131,56), sheet));
		put("!",new Img(new Point(134,43),new Point(136,56), sheet));
		put("?",new Img(new Point(138,43),new Point(144,56), sheet));
		put(".",new Img(new Point(145,43),new Point(148,56), sheet));
		put("-",new Img(new Point(149,43),new Point(155,56), sheet));
		put("*",new Img(new Point(156,43),new Point(159,56), sheet));
		put("_",new Img(new Point(0,57),new Point(0,70), sheet));
		put("\\qo\\",new Img(new Point(6,57),new Point(9,70), sheet));
		put("\\qc\\",new Img(new Point(12,57),new Point(17,70), sheet));
		put("\\ao\\",new Img(new Point(18,57),new Point(20,70), sheet));
		put("\\ac\\",new Img(new Point(21,57),new Point(23,70), sheet));
		put("'",new Img(new Point(21,57),new Point(23,70), sheet));
		put(",",new Img(new Point(45,57),new Point(48,70), sheet));
		put("\\x\\",new Img(new Point(50,57),new Point(57,70), sheet));
		put("/",new Img(new Point(58,57),new Point(63,70), sheet));
		put("A",new Img(new Point(64,57),new Point(69,70), sheet));
		put("B",new Img(new Point(70,57),new Point(75,70), sheet));
		put("C",new Img(new Point(76,57),new Point(81,70), sheet));
		put("D",new Img(new Point(82,57),new Point(87,70), sheet));
		put("E",new Img(new Point(88,57),new Point(93,70), sheet));
		put("F",new Img(new Point(94,57),new Point(99,70), sheet));
		put("G",new Img(new Point(100,57),new Point(105,70), sheet));
		put("H",new Img(new Point(106,57),new Point(111,70), sheet));
		put("I",new Img(new Point(112,57),new Point(117,70), sheet));
		put("J",new Img(new Point(119,57),new Point(123,70), sheet));
		put("K",new Img(new Point(124,57),new Point(129,70), sheet));
		put("L",new Img(new Point(130,57),new Point(135,70), sheet));
		put("M",new Img(new Point(136,57),new Point(141,70), sheet));
		put("N",new Img(new Point(142,57),new Point(147,70), sheet));
		put("O",new Img(new Point(148,57),new Point(153,70), sheet));
		put("P",new Img(new Point(154,57),new Point(159,70), sheet));
		put("Q",new Img(new Point(160,57),new Point(165,70), sheet));
		put("R",new Img(new Point(166,57),new Point(171,70), sheet));
		put("S",new Img(new Point(172,57),new Point(177,70), sheet));
		put("T",new Img(new Point(178,57),new Point(183,70), sheet));
		put("U",new Img(new Point(184,57),new Point(189,70), sheet));
		put("V",new Img(new Point(190,57),new Point(195,70), sheet));
		put("W",new Img(new Point(196,57),new Point(201,70), sheet));
		put("X",new Img(new Point(202,57),new Point(207,70), sheet));
		put("Y",new Img(new Point(208,57),new Point(213,70), sheet));
		put("Z",new Img(new Point(214,57),new Point(219,70), sheet));
		put("a",new Img(new Point(0,71),new Point(5,84), sheet));
		put("b",new Img(new Point(6,71),new Point(11,84), sheet));
		put("c",new Img(new Point(12,71),new Point(17,84), sheet));
		put("d",new Img(new Point(18,71),new Point(23,84), sheet));
		put("e",new Img(new Point(24,71),new Point(29,84), sheet));
		put("f",new Img(new Point(30,71),new Point(34,84), sheet));
		put("g",new Img(new Point(35,71),new Point(40,84), sheet));
		put("h",new Img(new Point(41,71),new Point(46,84), sheet)); // START HERE
		put("i",new Img(new Point(47,71),new Point(50,84), sheet));
		put("j",new Img(new Point(51,71),new Point(56,84), sheet));
		put("k",new Img(new Point(57,71),new Point(62,84), sheet));
		put("l",new Img(new Point(63,71),new Point(66,84), sheet));
		put("m",new Img(new Point(67,71),new Point(72,84), sheet));
		put("n",new Img(new Point(73,71),new Point(77,84), sheet));
		put("o",new Img(new Point(78,71),new Point(83,84), sheet));
		put("p",new Img(new Point(84,71),new Point(89,84), sheet));
		put("q",new Img(new Point(90,71),new Point(95,84), sheet));
		put("r",new Img(new Point(96,71),new Point(100,84), sheet));
		put("s",new Img(new Point(101,71),new Point(105,84), sheet));
		put("t",new Img(new Point(106,71),new Point(110,84), sheet));
		put("u",new Img(new Point(111,71),new Point(116,84), sheet));
		put("v",new Img(new Point(117,71),new Point(122,84), sheet));
		put("w",new Img(new Point(123,71),new Point(128,84), sheet));
		put("x",new Img(new Point(129,71),new Point(134,84), sheet));
		put("y",new Img(new Point(135,71),new Point(141,84), sheet));
		put("z",new Img(new Point(142,71),new Point(148,84), sheet));
		put("\\ARROW\\",new Img(new Point(149,73),new Point(154,82), sheet));
		put(" ",new Img(new Point(175,71),new Point(180,84), sheet));
	}};
	
	public Img getCharacter(String s){
		Point[] newP = chars.get(s).minusVector(vectors[this.toInt()]);
		return new Img(newP[0],newP[1],sheet);
	}
	
	public Color getColor(){
		return bg[this.toInt()];
	}
	
	public int toInt(){
		switch(this){
		case WHITE:
			return 0;
		case GREY:
			return 1;
		case DBLUE:
			return 2;
		case DRED:
			return 3;
		case LBLUE:
			return 4;
		case PINK:
			return 5;
		case LRED:
			return 6;
		default:
			return -1;
		}
	}
}
