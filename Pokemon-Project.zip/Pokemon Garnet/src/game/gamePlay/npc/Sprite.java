package game.gamePlay.npc;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import engine.Game;

public class Sprite {
	private Point vertex; //The point of which the NPC will be defined at the tile
	private Point p1, p2; //Upper left and lower right points in the sheet
	private String sheet; //Location of the sheet
	private int multiplier; //Multiplier found in the Game class
	public Sprite(int ax, int ay, String sheet, boolean mirrored){
		this.p1 = new Point(ax, ay);
		if(mirrored){
			this.p2 = new Point(ax-16, ay+21);
			this.vertex = new Point(ax, ay+5);
		}else{
			this.p2 = new Point(ax+16, ay+21);
			this.vertex = new Point(ax, ay+5);
		}
		this.sheet = sheet;
		this.multiplier = Game.multiplier;
	}
	
	public Sprite(){}
	
	public void drawSprite(int x, int y, Graphics g){
		g.drawImage(Toolkit.getDefaultToolkit().getImage(sheet),
		x,y,x+(int)(multiplier*(Math.abs(p2.getX()-p1.getX()))),y+(int)(multiplier*(Math.abs(p2.getY()-p1.getY()))),
		(int)p1.getX(),(int)p1.getY(),(int)p2.getX(),(int)p2.getY(),
		null);
	}
	
	public String toString(){
		return p1+" "+p2;
	}
	
	public String getPath(){
		return sheet;
	}
}
