package game.gamePlay.move;

import game.gamePlay.Pokemon;

public abstract class Move {
	public Move(){}
	
	public abstract void useMove(Pokemon user, Pokemon target);
}
