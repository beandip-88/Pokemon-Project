package game.gamePlay.npc;

import engine.maps.Map;

public class AIString{
	
	private MoveCommand[] moves;
	private int stringPos = 0;
	
	public AIString(MoveCommand[] moves){
		this.moves = moves;
	}
	
	public MoveCommand[] getCommands(){
		return moves;
	}
	
	public void increment(){
		stringPos++;
	}
	
	public int getStringPos(){
		return stringPos;
	}
	
	public void setStringPos(int a){
		this.stringPos = a;
	}

}
