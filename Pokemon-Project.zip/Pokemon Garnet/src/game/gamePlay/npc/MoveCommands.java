package game.gamePlay.npc;

public enum MoveCommands {
	UP, DOWN, LEFT, RIGHT;
}
