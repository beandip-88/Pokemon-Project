package game;

public class ToDoNotes {
	// THINGS TO DO IN THE FUTURE
	// -- 
	// 1. Fix NPC movement
			// I don't like how it's t-m-m-m-t-m-t;
			// Make it continuous m-m-m-m-m if keys are held and stuff.
				// Error: able to walk into a sign LOL
	// 2. Finish PauseMenu.java
			// Don't necessarily need to add all the goodies but just get the UI working
	// 3. NPC's
			// This is a bit of work. Need to make the NPC's and NPC AI.
	// 4. PokemonEnum
			// Mainly for images (toInt will be a pain in the butt)
	// ***** HIGHEST PRIORITY ***** //
}
