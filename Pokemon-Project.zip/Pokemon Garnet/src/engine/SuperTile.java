package engine;

import java.awt.Graphics;
import java.awt.Toolkit;
import java.io.Serializable;

public class SuperTile implements Serializable{
	private static final long serialVersionUID = -7588800020362352833L;
	private int[] vars, overlay;
	private int sheet1, sheet2;
	private int currentTile = 0;
	private Walkable w;
	private Animation a;
	private boolean isHm;
	public SuperTile(){
		
	}
	
	public Walkable getWalkable(){
		if(w == null){
			return Walkable.NULL;
		}
		return w;
	}
	
	public void drawBase(Graphics g, int x, int y){
		g.drawImage(Toolkit.getDefaultToolkit().getImage(getImg(this.sheet1)),
	            x,
	            y,
	            x+(16*Game.multiplier),
	            y+(16*Game.multiplier),
	            vars[currentTile],
	            vars[currentTile+1],
	            vars[currentTile]+16,
	            vars[currentTile+1]+16,
	            null);
	}
	
	public void drawOverlay(Graphics g, int x, int y){
		g.drawImage(Toolkit.getDefaultToolkit().getImage(getImg(this.sheet1)),
	            x,
	            y,
	            x+16*Game.multiplier,
	            y+16*Game.multiplier,
	            overlay[currentTile],
	            overlay[currentTile+1],
	            overlay[currentTile]+16,
	            overlay[currentTile+1]+16,
	            null);
	}
	
	public String getImg(int a){
        switch(a){
            case 1:
            return "src\\files\\Land.png";
            case 2:
            return "src\\files\\Buildings.png";
            case 3:
            return "src\\files\\Special.png";
        }
        return null;
    }
	
	public void onCreate(){
		if(this.w == Walkable.HM){
			this.isHm = true;
			this.w = Walkable.NULL;
		}
	}
	
	public void overrideWalk(Walkable wa){
		this.w = wa;
	}
	
    public void update(GameThread g){
        int ticks = g.getTicks();
        if(ticks%20==0){
            currentTile+=2;
            checkTile();
        }
    }
    
    private void checkTile(){
        if(currentTile>=vars.length/2){
            currentTile = 0;
        }
    }    
    
    public String toString(){
        String str = "";
        for(int a = 0;a<vars.length;a++){
            str+=Integer.toString(vars[a]);
        }
        if(overlay!=null){
            for(int a = 0;a<overlay.length;a++){
                str+=Integer.toString(overlay[a]);
            }
        }
        return str;
    }

    
    
}
