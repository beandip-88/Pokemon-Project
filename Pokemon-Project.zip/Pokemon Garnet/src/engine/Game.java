package engine;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import game.gamePlay.Pokenum;
import game.gamePlay.Settings;
import game.gamePlay.imgs.Img;
import game.gamePlay.npc.NPCContainer;
import game.gamePlay.playerInfo.Player;

public class Game {
	private KeyHandler keyboard;
	private ScreenFactory screenFactory;
	private final int width, height;
	private final String name;
	private JFrame frame;
	private GameThread gameThread;
	public static int multiplier;
	public static Img bouncingTriangle = new Img(new Point(363,170), new Point(373,176), "src\\files\\images\\Intro-screen.PNG");
	public static Player player; // the triangle will be used quite often (i think) so might as well put it here.
	private TileMap tiles;
	private MapContainer container;
	private int currentFont = 1;
	private Pokenum pokemon;
	private NPCContainer npcStatic;
	private EventHandler eventHandler;
	
	public Game(int w, int h, String n, int m){

		frame = new JFrame(n);
		this.name = n;
		Game.multiplier = m;
		this.width = w*m;
		this.height = h*m;
		frame.setIconImage(new ImageIcon("src\\files\\Pokeball_Icon.png").getImage());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(width, height);
		frame.setResizable(false);
		frame.setFocusable(true);
		frame.setLocationRelativeTo(null);
		screenFactory = new ScreenFactory(this);
		eventHandler = new EventHandler(this);
		keyboard = new KeyHandler(frame);
		player = new Player();
		frame.setVisible(true);
		gameThread = new GameThread(this);
		tiles = new TileMap();
		npcStatic = new NPCContainer();
		container = new MapContainer(this.screenFactory);
		frame.add(gameThread);
		pokemon = new Pokenum();
		System.out.println(pokemon.getPokeConstants(0).getName());
		Settings.init(this);
		Settings.obtainPokemon();
		
	}
	
	public ScreenFactory getScreenFactory(){
        return screenFactory;
    }
	
	public EventHandler getEventHandler(){
		return eventHandler;
	}

    public JFrame getWindow(){
        return frame;
    }

    public KeyHandler getKeyboard(){
        return keyboard;
    }
    
    public GameThread getGameThread(){
    	return gameThread;
    }
    
    public int getWidth(){
    	return width;
    }
    
    public int getHeight(){
    	return height;
    }
    
    public String getName(){
    	return name;
    }
    
    public Player getPlayer(){
    	return player;
    }
    
    public TileMap getTiles(){
    	return tiles;
    }
    
    public MapContainer getContainer(){
    	return container;
    }
    
    public int getFont(){
    	return currentFont;
    }
    
    public void setFont(int f){
    	this.currentFont = f;
    }
    
    public Pokenum getPokenum(){
    	return pokemon;
    }
    
    public NPCContainer getNPC(){
    	return npcStatic;
    }
}
