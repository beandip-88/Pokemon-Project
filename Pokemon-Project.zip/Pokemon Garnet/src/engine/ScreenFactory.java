package engine;

import java.util.Stack;

import game.screens.World;

public class ScreenFactory{
    private final Game game;
    private int pos = 0;
    private Stack<Screen> screens = new Stack<Screen>();
    public ScreenFactory(Game game){
        this.game = game;
    }
    
    public void showScreen(Screen screen){
    	screen.setPosition(pos);
    	pos++;
        this.screens.push(screen);
        this.screens.peek().onCreate();
    }
    
    public Screen getCurrentScreen(){
    	if(screens.size()==0){
    		return null;
    	}
        return screens.peek();
    }
    
    public Game getGame(){
        return game;
    }
    
    public void pop(){
    	this.screens.pop();
    	pos--;	
    }
    
    public Screen getScreenFromTop(int t){
    	return this.screens.get(t);
    }
    
    public int getSize(){
    	return screens.size();
    }
    
    public World getWorld(){
    	if(getCurrentScreen() instanceof World){
    		return (World) getCurrentScreen();
    	}else{
    		return null;
    	}
    }
}