package engine;

public abstract class Event {
	protected boolean occurance = false; //false by default
	
	public Event(){
		
	}
	
	public boolean getOccurance(){
		return occurance;
	}
	
	public void setOccurance(boolean o){
		this.occurance = o;
	}
	
	public boolean check(){return true;}
}
