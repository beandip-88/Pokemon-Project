package game.gamePlay.playerInfo;

public enum PlayerStatus {
	WALK,HM,SURF,RUN,BIKE,BALL,ITEM,FISH,FLY,NULL,WATERFALL;
	
	public boolean isEqual(PlayerStatus a, PlayerStatus b){
		return true;
	}
}
