package game.gamePlay.npc;

import java.util.ArrayList;

import engine.maps.Map;

public abstract class NPCAI {
	
	public NPCAI(){
	}
	
	public abstract void onTick(boolean[][] spacement, ArrayList<Integer> list, int index, Map map, NPC npc);
}
