package game.gamePlay.npc;

import java.awt.Graphics;
import java.util.ArrayList;

import engine.Game;
import engine.maps.Map;
import engine.Point;
import engine.Walkable;
import game.gamePlay.playerInfo.Player;
import game.gamePlay.playerInfo.PlayerStatus;

public abstract class NPC {
	protected ArrayList<ArrayList<Sprite>> sprites = new ArrayList<ArrayList<Sprite>>();
	protected Direction currentDirection;
	protected boolean canWalk = true;
	protected int position = 0;
	protected double xTile, yTile;
	protected int maxCounter;
	protected int counter = 0;
	protected boolean[] walks;
	protected boolean isPlayer;
	protected int pos;
	protected boolean justChanged = false;
	protected boolean azelf = true;
	protected final int[] traitor = new int[]{1,0,1,2};
	protected PlayerStatus p = PlayerStatus.WALK;
	protected boolean updatable = true;
	protected boolean drawable = false;
	protected int minX,minY,maxX,maxY;
	protected boolean canDraw = false;
	protected double minPosX, minPosY;
	protected boolean moveAndTurn = true;
	protected NPCAI ai = null;
	protected boolean hasAI = false;
	protected boolean updating = false;
	protected Point startingPoint = null;
	public NPC(int pos, int maxCounter, boolean player, boolean draw){ // 1 = constant, 2 = move, 3 = pyramid (1-2-EVENT-3-2-1
		this.currentDirection = Direction.SOUTH; // default direction (tbc)
		this.walks = new boolean[4];
		for(int a = 0;a < 4; a++){
			walks[a] = false;
		}
		spriteInit();
		this.isPlayer = player;
		this.pos = pos;
		this.canDraw = draw;
		this.maxCounter = maxCounter;
	}
	
	public NPC(int pos, int maxCounter, boolean player, PlayerStatus stat, boolean draw){ // 1 = constant, 2 = move, 3 = pyramid (1-2-EVENT-3-2-1
		this.currentDirection = Direction.SOUTH; // default direction (tbc)
		this.walks = new boolean[4];
		spriteInit();
		for(int a = 0;a < 4; a++){
			walks[a] = false;
		}
		this.isPlayer = player;
		this.pos = pos;
		this.maxCounter = maxCounter;
		this.p = stat;
		this.canDraw = draw;
	}
	
	public NPC(NPC n, int maxCounter, boolean player, boolean canDraw){
		this.currentDirection = Direction.SOUTH;
		this.walks = new boolean[4];
		for(int a = 0; a < 4; a++){
			walks[a] = false;
		}
		spriteInit();
		this.sprites = n.copySprites();
		this.isPlayer = player;
		this.maxCounter = maxCounter;
		this.canDraw =  canDraw;
	}
	
	public NPC(boolean draw){
		spriteInit();
		this.canDraw = draw;
	}
	
	public void setStartingPoint(Point p){
		this.startingPoint = p;
	}
	
	public boolean canDraw(){
		return canDraw;
	}
	
	public void setAI(NPCAI nc){
		this.ai = nc;
		this.hasAI = true;
	}
	
	public boolean hasAI(){
		return hasAI;
	}
	
	public void setUpdating(boolean b){
		this.updating = b;
	}
	
	public Point getStartingPoint(){
		return startingPoint;
	}
	
	public boolean updating(){
		return updating;
	}
	
	public NPCAI getAI(){
		return ai;
	}
	
	public void drawNPC(Graphics g){
		draw(g,(int)((this.getX() - this.minPosX - 1)*16*Game.multiplier), (int)((this.getY() - this.minPosY - 3)*16*Game.multiplier + (2*Game.multiplier)));
	}
	
	public void spriteInit(){
		for(int a = 0; a < 4; a++){
			sprites.add(new ArrayList<Sprite>());
		}
	}

	
	
	public void setSprite(Sprite[] s, Direction d){
		for(int a = 0; a < s.length; a++){
			sprites.get(Direction.getInt(d)).add(s[a]);
		}
	}
	
	public void setAllSprites(Sprite[][] s){
		for(int a = 0; a < 4; a++){
			setSprite(s[a],Direction.getDirection(a));
		}
	}
	
	public void draw(Graphics g, int x, int y){
		sprites.get(Direction.getInt(currentDirection)).get(traitor[position%4]).drawSprite(x, y, g);

	}
	
	public boolean getDir(Direction d){
		return walks[Direction.getInt(d)];
	}
	
	public void setDir(Direction d, boolean b, boolean cw){
		walks[Direction.getInt(d)] = b;
		this.azelf = cw;
	}
	
	public void setDir(Direction d, boolean b, boolean cw, boolean ddd){
		walks[Direction.getInt(d)] = b;
		this.azelf = cw;
		this.moveAndTurn = ddd;
	}
	
	public abstract String onInterract(Direction from);
	
	public void update(){
		if(!this.moveAndTurn){
			if(walks[0]){
				currentDirection = Direction.NORTH;
				walks[0] = false;
			}else if(walks[1]){
				currentDirection = Direction.EAST;
				walks[1] = false;
			}else if(walks[2]){
				currentDirection = Direction.SOUTH;
				walks[2] = false;
			}else if(walks[3]){
				currentDirection = Direction.WEST;
				walks[3] = false;
			}
			moveAndTurn = true;
			return;
		}
		setBounds();
		if(position==4){
			position = 0;
		}
		counter++;
		if(counter<maxCounter){
			canWalk = false;
		}
		if(counter == maxCounter){
			canWalk = true;
			if(position%2!=0){
				position++;
				if(yTile%1.0!=0.0){
					if(currentDirection == Direction.NORTH){
						yTile-=.5;
					}else{
						yTile+=.5;
					}
				}
				if(xTile%1.0!=0.0){
					if(currentDirection == Direction.EAST){
						xTile+=.5;
					}else{
						xTile-=.5;
					}
				}
				counter = 0;
				canWalk = false;
			}
		}
		if(position%2!=0){
			canWalk = false;
		}
		if(canWalk){
			if(walks[0]){
				position ++;
				counter = 0;
				canWalk = false;
				walks[0] = false;
				currentDirection = Direction.NORTH;
				if(currentDirection != Direction.NORTH || !azelf){
					
				}else{
					yTile-=.5;
				}
			}else if(walks[1]){
				walks[1] = false;
				position ++;
				counter = 0;
				canWalk = false;
				currentDirection = Direction.EAST;
				if(currentDirection != Direction.EAST || !azelf){
					
				}else{
					xTile+=.5;
				}
			}else if(walks[2]){
				walks[2] = false;
				position ++;
				counter = 0;
				canWalk = false;
				currentDirection = Direction.SOUTH;
				if(currentDirection != Direction.SOUTH || !azelf){
					
				}else{
					yTile+=.5;
				}
			}else if(walks[3]){
				walks[3] = false;
				position++;
				counter = 0;
				canWalk = false;
				currentDirection = Direction.WEST;
				if(currentDirection != Direction.WEST || !azelf){
					
				}else{
					xTile-=.5;
				}
			}
		}
		updating = false;
	}
	
	public Direction getCurrentDirection(){
		return currentDirection;
	}
	
	public boolean getCanWalk(){
		return canWalk;
	}

	public void setCoord(int i, int j) {
		this.xTile = i;
		this.yTile = j;
	}
	
	public boolean isPlayer(){
		return isPlayer;
	}
	
	public PlayerStatus getPlayerStatus(){
		return p;
	}
	
	public double getX(){
		return xTile;
	}
	
	public double getY(){
		return yTile;
	}
	
	public Point getNextStep(Direction d){
		switch(d){
		case NORTH:
			return new Point((int)xTile,(int)yTile-1);
		case SOUTH:
			return new Point((int)xTile,(int)yTile+1);
		case WEST:
			return new Point((int)xTile-1,(int)yTile);
		case EAST:
			return new Point((int)xTile+1,(int)yTile);
		default:
			return null;
		}
	}
	
	public Point getNextStep(){
		switch(currentDirection){
		case NORTH:
			return new Point((int)xTile,(int)yTile-1);
		case SOUTH:
			return new Point((int)xTile,(int)yTile+1);
		case WEST:
			return new Point((int)xTile-1,(int)yTile);
		case EAST:
			return new Point((int)xTile+1,(int)yTile);
		default:
			return null;
		}
	}
	
	public Point[] areaTaken(){
		Point[] p = null;
		boolean walk = false;
		for(int a = 0; a<walks.length;a++){
			if(walks[a]){
				walk = true;
			}
		}
		if(walk){
			p = new Point[]{getNextStep(), new Point((int)getX(),(int)getY())};
		}else{
			p = new Point[]{new Point((int)getX(), (int)getY())};
		}
		return p;
	}
	
	public boolean updatable(){
		return updatable;
	}
	
	public boolean up(NPC n, boolean[][] spacement, int timer, Map map){
		boolean b = true;
		if(timer > 20){
			b = false;
			if(n.currentDirection == Direction.NORTH){
				b = true;
			}else{
				n.setDir(Direction.NORTH, true, false);
			}
		}
		if(b&&spacement[getNextStep(Direction.NORTH).getX()][getNextStep(Direction.NORTH).getY()]&&Walkable.canWalk(n.getPlayerStatus(), map.getTileAt(n.getNextStep(Direction.NORTH).getX(), n.getNextStep(Direction.NORTH).getY()).getWalkable(), n.getCurrentDirection())){
			n.setDir(Direction.NORTH, true, true);
			return true;
		}else{
			n.setDir(Direction.NORTH, true, false);
			return false;
		}
	}
	
	public boolean down(NPC n, boolean[][] spacement, int timer, Map map){
		boolean b = true;
		if(timer > 20){
			b = false;
			if(n.currentDirection == Direction.SOUTH){
				b = true;
			}else{
				n.setDir(Direction.SOUTH, true, false);
			}
		}
		if(b&&spacement[n.getNextStep(Direction.SOUTH).getX()][n.getNextStep(Direction.SOUTH).getY()]&&Walkable.canWalk(n.getPlayerStatus(), map.getTileAt(n.getNextStep(Direction.SOUTH).getX(), n.getNextStep(Direction.SOUTH).getY()).getWalkable(), n.getCurrentDirection())){
			n.setDir(Direction.SOUTH, true, true); // turn and move
			return true;
		}else{
			n.setDir(Direction.SOUTH, true, false); // turn but not move
			return false;
		}
	}
	
	public boolean left(NPC n, boolean[][] spacement, int timer, Map map){
		boolean b = true;
		if(timer > 20){
			b = false;
			if(n.currentDirection == Direction.WEST){
				b = true;
			}else{
				n.setDir(Direction.WEST, true, false);
			}
		}
		if(b&&spacement[n.getNextStep(Direction.WEST).getX()][n.getNextStep(Direction.WEST).getY()]&&Walkable.canWalk(n.getPlayerStatus(), map.getTileAt(n.getNextStep(Direction.WEST).getX(), n.getNextStep(Direction.WEST).getY()).getWalkable(), n.getCurrentDirection())){
			n.setDir(Direction.WEST, true, true);
			return true;
		}else{
			n.setDir(Direction.WEST, true, false);
			return false;
		}
	}
	
	public boolean right(NPC n, boolean[][] spacement, int timer, Map map){
		boolean b = true;
		if(timer > 20){
			b = false;
			if(n.currentDirection == Direction.EAST){
				b = true;
			}else{
				n.setDir(Direction.EAST, true, false);
			}
		}
		if(b&&spacement[n.getNextStep(Direction.EAST).getX()][n.getNextStep(Direction.EAST).getY()]&&Walkable.canWalk(n.getPlayerStatus(), map.getTileAt(n.getNextStep(Direction.EAST).getX(), n.getNextStep(Direction.EAST).getY()).getWalkable(), n.getCurrentDirection())){
			n.setDir(Direction.EAST, true, true);
			return true;
		}else{
			n.setDir(Direction.EAST, true, false);
			return false;
		}
	}
	
	public void setBounds(){
		double localX = Game.player.getCurrentNPCState().getX();
		double localY = Game.player.getCurrentNPCState().getY();
		this.minPosX = localX - 8;
		this.minPosY = localY - 7;
		if(localX % 1 != 0){
			localX -= .5;
		}
		if(localY % 1 !=0){
			localY -= .5;
		}
		
		this.minX = (int)localX - 8;
		this.maxX = (int)localX + 8;
		this.minY = (int)localY - 7;
		this.maxY = (int)localY + 7;	
	}
	
	public int getMinX(){
		return minX;
	}
	
	public int getMinY(){
		return minY;
	}
	
	public int getMaxY(){
		return maxY;
	}
	
	public int getMaxX(){
		return maxX;
	}

	public ArrayList<ArrayList<Sprite>> copySprites(){
		return sprites;
	}
	
	public void reconstructAI(NPCAI ai){
		this.ai = ai;
	}
}
