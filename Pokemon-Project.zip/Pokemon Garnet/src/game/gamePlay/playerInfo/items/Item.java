package game.gamePlay.playerInfo.items;

public abstract class Item {
	
}
