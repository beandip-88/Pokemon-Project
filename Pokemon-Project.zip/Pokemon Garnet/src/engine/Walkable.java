package engine;

import game.gamePlay.npc.Direction;
import game.gamePlay.playerInfo.PlayerStatus;

public enum Walkable {
	WALKONLY, RUNUNDER, BIKEUNDER, BIKEONLY, SURFONLY, WATERFALLONLY, NULL, HM, N, E, S, W, SE, SW;

	public static boolean canWalk(PlayerStatus p, Walkable w, Direction d){
		switch(w){
		case WALKONLY:
			if(p == PlayerStatus.WALK){
				return true;
			}
		case RUNUNDER:
			if(p == PlayerStatus.WALK || p == PlayerStatus.RUN){
				return true;
			}
		case BIKEUNDER:
			if(p == PlayerStatus.WALK || p == PlayerStatus.RUN || p == PlayerStatus.BIKE){
				return true;
			}
		case SURFONLY:
			if(p == PlayerStatus.SURF){
				return true;
			}
		case BIKEONLY:
			if(p == PlayerStatus.BIKE){
				return true;
			}
		case WATERFALLONLY:
			if(p == PlayerStatus.WATERFALL){
				return true;
			}
		case NULL:
			return false;
		case N:
			if(d == Direction.NORTH){
				return true;
			}
		case S:
			if(d == Direction.SOUTH){
				return true;
			}
		case E:
			if(d == Direction.EAST){
				return true;
			}
		case W:
			if(d == Direction.WEST){
				return true;
			}
		case SE:
			if(d == Direction.EAST || d == Direction.SOUTH){
				return true;
			}
		case SW:
			if(d == Direction.SOUTH || d == Direction.WEST){
				return true;
			}
		default:
			return false;
		}
	}
}
