package game.gamePlay;

import java.util.ArrayList;

import engine.Point;
import game.gamePlay.imgs.Img;

public enum PokeSprite {
	FACEFRONT, FACEBACK, MINIA, MINIB;
	
	private final static String sheet = "src\\files\\images\\Pokemon.png";
	
	private static ArrayList<Img> sprites = new ArrayList<Img>(){/**
		 * 
		 */
		private static final long serialVersionUID = 512452345423524525L;

	{
		add(new Img(new Point(806,460), new Point(869,523),sheet));
		add(new Img(new Point(870,460), new Point(933,523),sheet));
		add(new Img(new Point(934,460), new Point(965,491),sheet));
		add(new Img(new Point(933,492), new Point(965,523),sheet));
	}}; // 806, 460 -- 933, 523
		// 934, 460 -- 965, 523
	
	public static Img getImg(PokeSprite s, Pokemon p){
		Point[] points = sprites.get(s.toInt()).minusVector(sprites.get(0).getPointA().plus(new Point(1+p.getPoke().getPoint().getX(),1+p.getPoke().getPoint().getY())));
		return new Img(points[0], points[1], sheet);
	}
	
	public int toInt(){
		switch(this){
		case FACEFRONT:
			return 0;
		case FACEBACK:
			return 1;
		case MINIA:
			return 2;
		case MINIB:
			return 3;
		default:
			return -1;
		}
	}
	
	
}
