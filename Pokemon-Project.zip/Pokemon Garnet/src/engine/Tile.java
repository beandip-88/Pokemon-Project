package engine;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Tile {
	private SuperTile t = null;
	private String path;
	public Tile(String path){
		this.path = path;
		try{
            FileInputStream fileIn = new FileInputStream(path);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            this.t = (SuperTile) in.readObject();
            in.close();
            fileIn.close();
            System.out.println("Loaded: " + path);
        }catch(IOException e){
        	e.printStackTrace();
        }catch(ClassNotFoundException i){
            i.printStackTrace();
        }
	}
	
	public SuperTile getTile(){
		return t;
	}
	
	public String toString(){
		return path;
	}
}
