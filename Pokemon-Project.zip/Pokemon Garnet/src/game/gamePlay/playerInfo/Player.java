package game.gamePlay.playerInfo;

import java.util.ArrayList;

import game.gamePlay.Pokemon;
import game.gamePlay.npc.*;

public class Player {
	private PlayerWalk playerWalk;
	private String name = "Bean Dip";
	private NPC currentNPC;
	private final String PATH = "src\\files\\images\\Player Images.png";
	private ArrayList<Pokemon> playerPokemon = new ArrayList<Pokemon>();
	public Player(){
		this.playerWalk = new PlayerWalk(){{
			setSprite(new Sprite[]{new Sprite(8,36,PATH,false), new Sprite(24,36,PATH,false), new Sprite(40,36,PATH,false)}, Direction.SOUTH);
			setSprite(new Sprite[]{new Sprite(8,68,PATH,false), new Sprite(24,68,PATH,false), new Sprite(40,68,PATH,false)}, Direction.NORTH);
			setSprite(new Sprite[]{new Sprite(8,100,PATH,false), new Sprite(24,100,PATH,false), new Sprite(40,100,PATH,false)}, Direction.WEST);
			setSprite(new Sprite[]{new Sprite(24,100,PATH,true), new Sprite(40,100,PATH,true), new Sprite(56,100,PATH,true)}, Direction.EAST);
		}};
		this.currentNPC = playerWalk;
	}
	
	public String getName(){
		return name;
	}
	
	public PlayerWalk getPlayerWalk(){
		return playerWalk;
	}
	
	public void setName(String n){
		this.name = n;
	}
	
	public NPC getCurrentNPCState(){
		return currentNPC;
	}
	
	public boolean addPokemon(Pokemon p){
		if(playerPokemon.size()<6){
			playerPokemon.add(p);
			return true;
		}
		return false;
	}
	
	public Pokemon getPokemon(int index){
		try{
			return playerPokemon.get(index);
		}catch(Exception e){
			return null;
		}
	}
	
	public int size(){
		return playerPokemon.size();
	}
}
