package engine;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class MapLoader implements Serializable{
	private MapInfo m = null;
	private String p;
	public MapLoader(String path){
		try{
            FileInputStream fileIn = new FileInputStream(path);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            this.m = (MapInfo)in.readObject();
            in.close();
            fileIn.close();
            System.out.println("Map loaded!");
        }catch(IOException e){
        	e.printStackTrace();
        }catch(ClassNotFoundException i){
            i.printStackTrace();
        }
	}
	
	public MapInfo getMap(){
		return m;
	}
}
