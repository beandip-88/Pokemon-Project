package game.gamePlay;

public enum PokeType {
	NORMAL,FIRE,WATER,ELECTRIC,GRASS,ICE,FIGHTING,POISON,
	GROUND,FLYING,PSYCHIC,BUG,ROCK,GHOST,DRAGON,NONE;
	
	private final double[][] typeChart = new double[][]{
		{1,1,1,1,1,1,1,1,1,1,1,1,.5,0,1},
		{1,.5,.5,1,2,2,1,1,1,1,1,2,.5,1,.5},
		{1,2,.5,1,.5,1,1,1,2,1,1,1,2,1,.5},
		{1,1,2,.5,.5,1,1,1,0,2,1,1,1,1,.5},
		{1,.5,2,1,.5,1,1,.5,2,.5,1,.5,2,1,.5},
		{1,.5,.5,1,2,.5,1,1,2,2,1,1,1,1,2},
		{2,1,1,1,1,2,1,.5,1,.5,.5,.5,2,0,1},
		{1,1,1,1,2,1,1,.5,.5,1,1,1,.5,.5,1},
		{1,2,1,2,.5,1,1,2,1,0,1,.5,2,1,1},
		{1,1,1,.5,2,1,2,1,1,1,1,2,.5,1,1},
		{1,1,1,1,1,1,2,2,1,1,.5,1,1,1,1},
		{1,.5,1,1,2,1,.5,.5,1,.5,2,1,1,.5,1},
		{1,2,1,1,1,2,.5,1,.5,2,1,2,1,1,1},
		{0,1,1,1,1,1,1,1,1,1,2,1,1,2,1},
		{1,1,1,1,1,1,1,1,1,1,1,1,1,1,2}
	};
	
	public int toInt(){
		switch(this){
		case NORMAL:
			return 0;
		case FIRE:
			return 1;
		case WATER:
			return 2;
		case ELECTRIC:
			return 3;
		case GRASS:
			return 4;
		case ICE:
			return 5;
		case FIGHTING:
			return 6;
		case POISON:
			return 7;
		case GROUND:
			return 8;
		case FLYING:
			return 9;
		case PSYCHIC:
			return 10;
		case BUG:
			return 11;
		case ROCK:
			return 12;
		case GHOST:
			return 13;
		case DRAGON:
			return 14;
		default:
			return -1;
		}
	}
	
	public double getTypeModifier(PokeType a, PokeType b){
		try{
			return typeChart[this.toInt()][a.toInt()] * typeChart[this.toInt()][b.toInt()];
		}catch(Exception e){
			return typeChart[this.toInt()][a.toInt()];
		}
	}
	
	public static PokeType invert(String s){
		return valueOf(s.toUpperCase());
	}
}
