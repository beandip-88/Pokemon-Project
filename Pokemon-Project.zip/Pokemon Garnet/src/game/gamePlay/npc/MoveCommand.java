package game.gamePlay.npc;

public class MoveCommand {
	private MoveCommands direction;
	private int timer;
	public MoveCommand(MoveCommands direction, int timer){
		this.direction = direction;
		this.timer = timer;
	}
	
	public MoveCommands getDirection(){
		return direction;
	}
	
	public int getTimer(){
		return timer;
	}
}
