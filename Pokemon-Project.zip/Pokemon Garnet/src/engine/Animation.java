package engine;

public enum Animation {
	CONSTANT,DOOR,HM,BEACH
}
