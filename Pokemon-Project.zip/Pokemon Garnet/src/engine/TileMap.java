package engine;

import java.util.HashMap;

public class TileMap {
	private HashMap<String, SuperTile> map = new HashMap<String, SuperTile>();
	public TileMap(){
		
	}
	
	public boolean checkForTile(String index){
		return map.containsKey(index);
	}
	
	public void addTile(String k){
		k = "src\\files\\tiles\\"+k;
		if(!checkForTile(k)){
			Tile ti = null;
			SuperTile t = null;
			try{
				ti = new Tile(k);
				t = ti.getTile();
				map.put(k, t);
			}catch(NullPointerException n){
				n.printStackTrace();
			}
		}

	}
	
	public SuperTile getTile(String key){
		return map.get(key);
	}
}
