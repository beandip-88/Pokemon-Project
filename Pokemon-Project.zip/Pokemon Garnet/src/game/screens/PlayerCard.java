package game.screens;

import java.awt.Graphics;
import java.awt.event.KeyEvent;

import engine.Screen;
import engine.ScreenFactory;

public class PlayerCard extends Screen {

	public PlayerCard(ScreenFactory screenFactory) {
		super(screenFactory, false);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onUpdate() {
		if(getKey(KeyEvent.VK_B)){
			getScreenFactory().pop();
		}
	}

	@Override
	public void onDraw(Graphics g) {
		// TODO Auto-generated method stub
		
	}

}
