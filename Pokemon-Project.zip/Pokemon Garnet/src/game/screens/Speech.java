package game.screens;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import engine.Game;
import game.gamePlay.FrameType;
import game.gamePlay.Settings;
import game.gamePlay.TextType;
import game.gamePlay.imgs.*;
import engine.Screen;
import engine.ScreenFactory;

public class Speech extends Screen {
	private String toSay;
	private ArrayList<String> imgs = new ArrayList<String>();
	private int stringPos = 0;
	private int linePos = 0;
	private int frame = 0;
	private int speed = Settings.TEXT_SPEED;
	private int[] mdos = new int[]{3,2,1};
	private boolean flag = false;
	private boolean bouncingBetty = false;
	protected boolean endOfTheLine = false;
	private boolean up = true;
	private ArrayList<Integer> vals = new ArrayList<Integer>();
	protected TextType currentText = TextType.DBLUE;
	protected FrameType currentFrame = Settings.FRAME;
	protected boolean isMessage = false;
	private int val;
	public Speech(ScreenFactory screenFactory, String toSay, TextType t) {
		super(screenFactory, true);
		this.toSay = toSay;
		this.currentText = t;
	}
	public Speech(ScreenFactory screenFactory, String toSay, TextType t, FrameType override){
		super(screenFactory, true);
		this.toSay = toSay;
		this.currentText = t;
	}
	public Speech(ScreenFactory screenFactory, String toSay, TextType t, boolean isMessage){
		super(screenFactory, true);
		this.toSay = toSay;
		this.currentText = t;
		this.isMessage = isMessage;
	}
	@Override
	public void onCreate() {
		establishLines();
		
	}
	
	@Override
	public void onUpdate() {
		if(getKey(KeyEvent.VK_A)||getKey(KeyEvent.VK_B)){
			flag = true;
		}
	}
	
	@Override
	public void onDraw(Graphics g) {
		
		if(this.viewUnder){
			if(this.position != 0){
				if(!isMessage){
					getScreenFactory().getScreenFromTop(this.position-1).onDraw(g);
				}
			}
		}
		g.setColor(currentText.getColor());
		g.fillRect((11*Game.multiplier),(132*Game.multiplier),(219*Game.multiplier),(44*Game.multiplier)); // screen is 240x190 px w/o Game.multiplier
									// each letter is about 15px tall * 2 = 30 in height minimum
									// we should have a 7 px buffer on the three sides
									// with an extra 5 pixels on the top. That gives us 30+21+5 = 56 px tall.
									// the y will be 240-7 (side buffer) - 56.
									// the x will just be 7 due to the side buffering
									// the height is obviously 56 px
									// the width will be 190-14 = 176 px.
		currentFrame.getImg("Right").drawVert(g, 224*Game.multiplier, 134*Game.multiplier, 5);
		currentFrame.getImg("Left").drawVert(g, 6*Game.multiplier, 134*Game.multiplier, 5);
		currentFrame.getImg("Top").drawHor(g, 13*Game.multiplier, 127*Game.multiplier, 27);
		currentFrame.getImg("Bottom").drawHor(g, 13*Game.multiplier, 170*Game.multiplier, 27);
		currentFrame.getImg("UpperLeft").drawBase(g, 6*Game.multiplier, 127*Game.multiplier);
		currentFrame.getImg("UpperRight").drawBase(g, 224*Game.multiplier, 127*Game.multiplier);
		currentFrame.getImg("LowerRight").drawBase(g, 224*Game.multiplier, 170*Game.multiplier);
		currentFrame.getImg("LowerLeft").drawBase(g, 6*Game.multiplier, 170*Game.multiplier);
		
		frame++;
		if(bouncingBetty){
			if(up){
				Game.bouncingTriangle.drawBase(g, 210*Game.multiplier, 160*Game.multiplier);
			}else{
				Game.bouncingTriangle.drawBase(g, 210*Game.multiplier, 158*Game.multiplier);
			}
			if(frame%20==0){
				up=!up;
			}
		}
		if(flag&&endOfTheLine){
			if(!isMessage){
				getScreenFactory().pop();
			}
			return;
		}
		if(flag&&bouncingBetty){
			linePos++;
			flag = false;
			bouncingBetty = false;
		}
		if(frame % mdos[speed] == 0){
			if(!bouncingBetty&&!endOfTheLine){
				stringPos++;
			}
			try{
				val = vals.get(linePos);
			}catch(IndexOutOfBoundsException i){
				val = imgs.size()-1;
			}
			if(stringPos == val){ // FIX THIS SHIT
				if(vals.size()==0){
					endOfTheLine = true;
				}else if(linePos%2==0){
					if(linePos!=vals.size()-1){
						linePos++;
					}else{
						endOfTheLine = true;
					}
				}else{
					if(linePos==vals.size()-1){
						endOfTheLine = true;
					}else{
						bouncingBetty = true;
					}
				}
			}
		}
		flag = false;
		if(linePos%2==0&&vals.size()!=0){
			try{
				drawItems(g,vals.get(linePos-1),stringPos,140*Game.multiplier);
			}catch(Exception e){ //LinePos == 0
				drawItems(g,0,stringPos,140*Game.multiplier); //1st line
			}
		}else if(vals.size()!=0){
			drawItems(g,vals.get(linePos-1),stringPos,155*Game.multiplier); //2nd line
			try{
				drawItems(g,vals.get(linePos-2),vals.get(linePos-1),140*Game.multiplier);
			}catch(Exception e){ //LinePos == 0
				drawItems(g,0,vals.get(linePos-1),140*Game.multiplier);
			}			
		}
		if(vals.size()==0){
			drawItems(g,0,stringPos+1,140*Game.multiplier);
		}
	}
	
	public void establishLines(){
		for(int a = 0; a < toSay.length(); a++){
			String sub = getNextString(toSay,a);
			if(sub.substring(0, 1).equals("\\")){
				a+=sub.length()-1;
			}
			imgs.add(sub);
			//System.out.println(sub);
		}
		int maxSize = 0;
		for(int a = 0; a < imgs.size(); a++){
			Img temp = currentText.getCharacter(imgs.get(a));
			maxSize+=temp.getPx();
		}
		int max = maxSize/180;
		int totalPx=0;
		int pxCounter = 0;
		int placeHolder = 0;
		for(int a = 0; a < max; a++){
			for(int b = placeHolder; b < imgs.size(); b++){
				if(totalPx < 180){
					totalPx += currentText.getCharacter(imgs.get(b)).getPx();
					placeHolder++;
				}else{
					break;
				}
			}
			while(!(imgs.get(placeHolder-1).equals(" ")||placeHolder == imgs.size())){
				placeHolder--;
				totalPx -= currentText.getCharacter(imgs.get(placeHolder)).getPx();
			}
			vals.add(placeHolder);
			pxCounter += totalPx;
			totalPx = 0;
			if(a+1==max&&pxCounter<maxSize){
				max++;
			}else{
			}
		}
		int prev = 0;
		for(int a = 0; a < vals.size(); a++){
			for(int b = prev; b < vals.get(a); b++ ){
						// How to display the items
			}
			prev = vals.get(a);
			System.out.println();
		}
	}
	
	public String getNextString(String s, int a){
		if(s.substring(a,a+1).equals("\\")){
			for(int b = a+1; b < s.length(); b++){
				if(s.substring(b,b+1).equals("\\")&&b!=s.length()){
					return s.substring(a,b+1);
				}
			}
			return null;
		}else{
			return s.substring(a,a+1);
		}
	}
	
	public synchronized void drawItems(Graphics g, int start, int end, int yVal){
		int xVal = 22*Game.multiplier;
		Img temp = null;
		for(int a = start; a < end; a++){
			temp = currentText.getCharacter(imgs.get(a));
			temp.drawBase(g, xVal, yVal);
			xVal+=temp.getPx()*Game.multiplier;
		}
	}
}