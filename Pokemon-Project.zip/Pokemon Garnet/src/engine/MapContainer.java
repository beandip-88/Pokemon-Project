package engine;

import java.util.HashMap;

import engine.maps.*;
import game.gamePlay.npc.*;

public class MapContainer {
	private ScreenFactory screenFactory;
	private HashMap<String,Map> maps;
	
	public MapContainer(ScreenFactory screenFactory){
		this.screenFactory = screenFactory;
		maps = new HashMap<String,Map>(){{;
		put("src\\files\\maps\\Area 1.MAP",new TestMap("src\\files\\maps\\Area 1.MAP", screenFactory.getGame()){{
			add(new Point(9,12),new Sign("If a train is moving at light speed, and you are facing the direction it's moving, and there is a mirror in front of you, do you see your reflection?"));
			add(new Point(3,14),new Sign("Grocery List: Eggs, Milk, Cream.")); // Fix colon.... :(
			add(new Point(9,15), new GeneralNPC("Whaddup bro", screenFactory.getGame().getNPC().getByID(0), "Cameron",new Point(9,15)){{
				setAI(new ProgramAI(new AIString(new MoveCommand[]{
						new MoveCommand(MoveCommands.UP,0),
						new MoveCommand(MoveCommands.DOWN,0)
				})));
			}}); // how to make a programmed AI
			add(new Point(13,13), new GeneralNPC("Hey man", screenFactory.getGame().getNPC().getByID(0), "Dankster",new Point(13,13)){{
				setAI(new RandomPath(2));
			}}); // how to make a randomPath AI
		}}); //how to 'fully' make a map (obviously this is very basic and this class will be huge
	}};
	}
	
	public Map getMap(String s){
		maps.get(s).init(screenFactory);
		return maps.get(s);
	}
}
