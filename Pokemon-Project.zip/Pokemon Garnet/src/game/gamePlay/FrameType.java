package game.gamePlay;

import java.util.HashMap;

import engine.Point;
import game.gamePlay.imgs.Img;

public enum FrameType {
	FRAME1, FRAME2, FRAME3, FRAME4, FRAME5, FRAME6, FRAME7, FRAME8, FRAME9,
	HIDDENFRAME, // BLACK AND WHITE ONE
	RSE1, RSE2, RSE3, RSE4, RSE5, RSE6, RSE7, RSE8, RSE9, RSE10,
	RSE11, RSE12, RSE13, RSE14, RSE15, RSE16, RSE17, RSE18;
	
	private final String frames = "src\\files\\images\\Menu Frames.png";
	
	@SuppressWarnings("serial")
	private HashMap<String,Img> menuFrames = new HashMap<String,Img>(){{
		put("UpperLeft", new Img(new Point(4,17),new Point(11,24),frames));
		put("Top", new Img(new Point(13,17), new Point(20,24),frames));
		put("UpperRight", new Img(new Point(22,17), new Point(29,24),frames));
		put("Right", new Img(new Point(22,26), new Point(29,33),frames));
		put("LowerRight", new Img(new Point(22,35), new Point(29,42),frames));
		put("Bottom", new Img(new Point(13,35), new Point(20,42),frames));
		put("LowerLeft", new Img(new Point(4,35), new Point(11,42),frames));
		put("Left", new Img(new Point(4,26), new Point(11,33),frames));
	}}; //4,17
	
	private Point[] vectors = new Point[]{
		new Point(-4,-98),new Point(-64,-98),new Point(-94,-98),new Point(-124,-98),
		new Point(-154,-98),new Point(-184,-98),new Point(-214,-98),new Point(-244,-98),
		new Point(-274,-98),new Point(-34,-98),new Point(-64,-17),new Point(-94,-17),
		new Point(-124,-17),new Point(-154,-17),new Point(-184,-17),new Point(-214,-17),
		new Point(-244,-17),new Point(-274,-17),new Point(-4,-47),new Point(-34,-47),
		new Point(-64,-47),new Point(-94,-47),new Point(-124,-47),new Point(-154,-47),
		new Point(-184,-47),new Point(-214,-47),new Point(-244,-47),new Point(-274,-47)
	};
	
	public Img getImg(String s){
		Point[] newP = menuFrames.get(s).minusVector(vectors[Settings.FRAME.toInt()].plus(new Point(4,17)));
		return new Img(newP[0], newP[1], frames);
	}
	
	public Point getVector(FrameType f){
		return vectors[f.toInt()];
	}
	
	public int toInt(){
		switch(this){
		case FRAME1:
			return 0;
		case FRAME2:
			return 1;
		case FRAME3:
			return 2;
		case FRAME4:
			return 3;
		case FRAME5:
			return 4;
		case FRAME6:
			return 5;
		case FRAME7:
			return 6;
		case FRAME8:
			return 7;
		case FRAME9:
			return 8;
		case HIDDENFRAME:
			return 9;
		case RSE1:
			return 10;
		case RSE2:
			return 11;
		case RSE3:
			return 12;
		case RSE4:
			return 13;
		case RSE5:
			return 14;
		case RSE6:
			return 15;
		case RSE7:
			return 16;
		case RSE8:
			return 17;
		case RSE9:
			return 18;
		case RSE10:
			return 19;
		case RSE11:
			return 20;
		case RSE12:
			return 21;
		case RSE13:
			return 22;
		case RSE14:
			return 23;
		case RSE15:
			return 24;
		case RSE16:
			return 25;
		case RSE17:
			return 26;
		case RSE18:
			return 27;
		default:
			return -1;
		}
	}
}
