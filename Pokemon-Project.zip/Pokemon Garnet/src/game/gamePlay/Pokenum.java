package game.gamePlay;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

// Little bit of a play on words lol
// Even though it's not really an enum hahah

public class Pokenum {
	private File info = new File("src\\files\\other\\Pokemon Info.tsv");
	private Scanner sc;
	private Pokeconst[] pokeconsts = new Pokeconst[151];
	
	public Pokenum(){
		try{
			sc = new Scanner(info);
		}catch(FileNotFoundException f){
			f.printStackTrace();
		}
		for(int a = 0; a < 151; a++){ // Read in from tab delimited file
			String n = sc.next();
			if(n.equals("Mr.Mime")){ // Scanner bugs out with the space in his name so this should fix it
				n = "Mr. Mime"; // Well, nobody uses him anyways soooo
			}
			pokeconsts[a] = new Pokeconst(n,a,new String[]{sc.next(),sc.next()},new int[]{sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt()},sc.next(),sc.nextInt(),new int[]{sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt()}, sc.nextInt(), sc.nextInt());
		}
	}
	
	public Pokeconst getPokeConstants(int index){
		return pokeconsts[index]; 
	}
}
