package game.gamePlay.imgs;

import java.awt.Graphics;
import java.awt.Toolkit;

import engine.Game;
import engine.Point;

public class Img {
	private Point a1,a2;
	private String sheet;
	public Img(Point a1, Point a2, String sheet){
		this.a1 = a1;
		this.a2 = a2;
		this.sheet = sheet;
	}
	
	public Point getPointA(){
		return a1;
	}
	
	public Point getPointB(){
		return a2; 
	}
	
	public int getPx(){
		return Math.abs(a1.getX()-a2.getX())+1;
	}
	
	public int getPy(){
		return Math.abs(a1.getY()-a2.getY())+1;
	}
	
	public void drawBase(Graphics g, int x, int y){
		g.drawImage(Toolkit.getDefaultToolkit().getImage(sheet),
	            x,
	            y,
	            x+getPx()*Game.multiplier,
	            y+getPy()*Game.multiplier,
	            a1.getX(),
	            a1.getY(),
	            a2.getX(),
	            a2.getY(),
	            null);
	}
	
	public void drawBase(Graphics g, int x, int y, double xScale, double yScale){
		g.drawImage(Toolkit.getDefaultToolkit().getImage(sheet),
				x,
				y,
				x+(int)(getPx()*Game.multiplier*xScale),
				y+(int)(getPy()*Game.multiplier*yScale),
				a1.getX(),
				a1.getY(),
				a2.getX(),
				a2.getY(),
				null);
	}
	
	public void drawHor(Graphics g, int x, int y, int num){
		for(int a = 0; a < num; a++){
			drawBase(g,x,y);
			x+=getPx()*Game.multiplier;
		}
	}
	
	public void drawVert(Graphics g, int x, int y, int num){
		for(int a = 0; a < num; a++){
			drawBase(g,x,y);
			y+=getPy()*Game.multiplier;
		}
	}
	
	public String toString(){
		return a1.toString() + "+" + a2.toString();
	}
	
	public Point[] minusVector(Point vector){
		return new Point[]{
			new Point(a1.getX()-vector.getX(),a1.getY()-vector.getY()),
			new Point(a2.getX()-vector.getX(),a2.getY()-vector.getY())
		};
	}
}
