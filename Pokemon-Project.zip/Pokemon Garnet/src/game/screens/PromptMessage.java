package game.screens;

import java.awt.Graphics;
import java.awt.event.KeyEvent;

import engine.Game;
import engine.Point;
import engine.ScreenFactory;
import game.gamePlay.TextType;
import game.gamePlay.imgs.Img;

public class PromptMessage extends Speech{
	private int answer = 0;
	private boolean hasAnswered = false;
	private int pos = 0;
	private String[] choices;
	private int x,y;
	private int height, width;
	private int xFactor,yFactor;
	private int[] yArgs;
	private int xOffset;
	public PromptMessage(ScreenFactory screenFactory, String question, String[] choices, int x, int y) {
		super(screenFactory, question, TextType.GREY, true);
		this.choices = choices;
		this.x = x;
		this.y = y;
		yArgs = new int[choices.length];
	}

	@Override
	public void onCreate() {
		super.onCreate();
		height = (18*choices.length+19);
		width = 50;
		xFactor = (int)(width / 8)-1;
		yFactor = (int)(height / 8)-1;
		int r = y;
		for(int b = 0; b < yArgs.length; b++){
			yArgs[b] = (y*Game.multiplier) + (11*Game.multiplier) + (18*Game.multiplier*b);
		}
		xOffset = (x+17);
	}

	@Override
	public void onUpdate() {
		if(endOfTheLine){
			if(getKey(KeyEvent.VK_A)){
				hasAnswered = true;
				answer = pos;
			}else if(getKey(KeyEvent.VK_UP)){
				pos--;
			}else if(getKey(KeyEvent.VK_DOWN)){
				pos++;
			}
			checkPos();
		}else{
			super.onUpdate();
		}
	}
	
	public void checkPos(){
		if(pos == choices.length){
			pos = 0;
		}
		if(pos == -1){
			pos = choices.length-1;
		}
	}
	
	public boolean hasAnswered(){
		return hasAnswered;
	}
	
	public int getAnswer(){
		return answer;
	}

	@Override
	public void onDraw(Graphics g) {
		super.onDraw(g);
		if(this.viewUnder){
			if(this.position != 0){
				getScreenFactory().getScreenFromTop(this.position-1).onDraw(g);
			}
		}
		if(endOfTheLine){
			g.setColor(currentText.getColor());
			g.fillRect((x+8)*Game.multiplier, (y+8)*Game.multiplier, (width-16)*Game.multiplier, (height-16)*Game.multiplier);
			currentFrame.getImg("Top").drawHor(g, (x+8)*Game.multiplier, y*Game.multiplier, xFactor);
			currentFrame.getImg("Bottom").drawHor(g, (x+8)*Game.multiplier, (y+height-8)*Game.multiplier, xFactor);
			currentFrame.getImg("Left").drawVert(g, x*Game.multiplier, (y+8)*Game.multiplier, yFactor);
			currentFrame.getImg("Right").drawVert(g, (x+width-8)*Game.multiplier, (y+8)*Game.multiplier, yFactor);
			currentFrame.getImg("UpperLeft").drawBase(g, x*Game.multiplier, y*Game.multiplier);
			currentFrame.getImg("UpperRight").drawBase(g, (x+width-8)*Game.multiplier, y*Game.multiplier);
			currentFrame.getImg("LowerRight").drawBase(g, (x+width-8)*Game.multiplier, (y+height-8)*Game.multiplier);
			currentFrame.getImg("LowerLeft").drawBase(g, x*Game.multiplier, (y+height-8)*Game.multiplier);
			for(int a = 0; a < choices.length; a++){
				drawItems(g,0,choices[a].length(), yArgs[a], choices[a]);
			}
			currentText.getCharacter("\\ARROW\\").drawBase(g, (x+9)*Game.multiplier, yArgs[pos]+1*Game.multiplier);
		}
	}
	
	public synchronized void drawItems(Graphics g, int start, int end, int yVal, String s){
		int xVal = xOffset*Game.multiplier;
		Img temp = null;
		for(int a = start; a < end; a++){
			temp = currentText.getCharacter(s.substring(a,a+1));
			temp.drawBase(g, xVal, yVal);
			xVal+=temp.getPx()*Game.multiplier;
		}
	}

	public boolean endOfTheLine(){
		return endOfTheLine;
	}
}
