package game.gamePlay;

import java.util.ArrayList;

import engine.ScreenFactory;
import game.gamePlay.status.*;
import game.gamePlay.move.*;

public class Pokemon {
	private IV[] ivs = new IV[6];
	private int level;
	private Pokeconst poke;
	private int[] evs = new int[6];
	private int xp;
	private String nickName;
	private StatusEffect currentStatus = new NoStatus(); // by default, Pokemon have no status effect
	private int[] stats = new int[6];
	private int[] battleStats = new int[8]; // regular stats plus accuracy and evasiveness
	private ArrayList<Move> moves = new ArrayList<Move>();
	
	// Creation constructor
	public Pokemon(ScreenFactory sc, int id, int level){
		this.level = level; // what do you think?
		this.poke = sc.getGame().getPokenum().getPokeConstants(id-1); // generic pokemon information
		this.xp = GrowthRate.getNextLevel(level, poke.getGrowthRate()); // exp that the unit has on creation
		for(int a = 0; a < 6; a++){
			ivs[a] = new IV(); // set IV's to a random number
			evs[a] = 0; // set EV's to zero
		}
		this.nickName = poke.getName(); // default name
		stats[0] = calcHP();
		for(int a = 1; a < 6; a++){
			stats[a] = calcStat(a);
		}
		for(int a = 0; a < 6; a++){
			battleStats[a] = stats[a];
		}
		battleStats[6] = 100; //accuracy
		battleStats[7] = 100; //evasiveness
	}
	
	// Override constructor
	public Pokemon(ScreenFactory sc, int id, int level, int att, int hp, int def, int sat, int sde, int spe, Move[] moves){
		this.level = level;
		this.poke = sc.getGame().getPokenum().getPokeConstants(id-1);
		stats[0] = hp;
		stats[1] = att;
		stats[2] = def;
		stats[3] = sat;
		stats[4] = sde;
		stats[5] = spe;
		setMoves(moves);
	}
	
	public void levelUp(){
		level++;
		stats[0] = calcHP();
		for(int a = 1; a < 6; a++){
			stats[a] = calcStat(a);
		}
	}
	
	public void setMoves(Move[] moves){
		for(int a = 0; a < moves.length; a++){
			this.moves.add(moves[a]);
		}
	}
	
	public void setNickname(String nick){
		this.nickName = nick;
	}
	
	public String getNickName(){
		return nickName;
	}
	
	public int getLevel(){
		return level;
	}
	
	public int calcHP(){
		return (int) ((poke.getHealth()*2+ivs[0].getIV()+((poke.getHealthEV())/4.0)*level)/100.0 + level + 10);
	}
	
	public int calcStat(int x){
		return (int) (((2*poke.getStat(x)+ivs[x].getIV()+(poke.getEV(x)/4.0)*level)/100.0) + 5);
	}
	
	public void setStatus(StatusEffect s){
		this.currentStatus = s;
	}
	
	public StatusEffect getStatusEffect(){
		return currentStatus;
	}
	
	public void changeHealth(int delta){
		battleStats[0] += delta;
		if(battleStats[0] < 0){
			battleStats[0] = 0;
		}
		if(battleStats[0] > stats[0]){
			battleStats[0] = stats[0];
		}
	}
	
	public void changeStat(int stat, int delta){
		battleStats[stat] += delta;
	}
	
	public void resetStats(){ // After each battle you reset all stats except health
		for(int a = 1; a < 6; a++){
			battleStats[a] = stats[a];
		}
		battleStats[6] = 100;
		battleStats[7] = 100;
	}
	
	public Pokeconst getPoke(){
		return poke;
	}
}
