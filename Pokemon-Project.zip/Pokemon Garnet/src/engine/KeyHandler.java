package engine;


import java.awt.Component;
import java.awt.event.*;

public class KeyHandler implements KeyListener{
    private boolean[] keys; 
    public KeyHandler(Component c){
        c.addKeyListener(this); //Automatically adds this to the component calling this class
        keys = new boolean[256]; //Creates an array for the 256 keys
    }
    
    public void keyTyped(KeyEvent e){//Method is unused but still needed because it's an interface
    }
    
    public void keyPressed(KeyEvent e){//When the key is pressed, it will bring true in the array
        keys[e.getKeyCode()] = true;
    }
    
    public void keyReleased(KeyEvent e){//When the key is released, it will bring false in the array
        keys[e.getKeyCode()] = false;
    }
    
    public boolean getKey(int key){//Returns the boolean for the desired key in the array
        if(keys[key]){
        	keys[key] = false;
        	return true;
        }else{
        	return false;
        }
    }
    
    public boolean getKeyConst(int key){
    	return keys[key];
    }
}