package game.gamePlay.npc;

import java.util.ArrayList;

public class NPCContainer {
	private ArrayList<NPC> npcs = new ArrayList<NPC>();
	private final String PATH = "src\\files\\images\\Npc Sheet.png";
	public NPCContainer(){
		npcs = new ArrayList<NPC>(){{
			add(new GeneralNPC("Whaddup fam?"){{ // generic text
				setSprite(new Sprite[]{new Sprite(18,1,PATH,false),new Sprite(0,1,PATH,false),new Sprite(33,1,PATH,true)},Direction.SOUTH); // Walk1, stand, walk2
				setSprite(new Sprite[]{new Sprite(19,23,PATH,false),new Sprite(0,24,PATH,false),new Sprite(34,23,PATH,true)},Direction.NORTH);
				setSprite(new Sprite[]{new Sprite(18,46,PATH,false),new Sprite(0,46,PATH,false),new Sprite(34,46,PATH,false)},Direction.WEST);
				setSprite(new Sprite[]{new Sprite(33,46,PATH,true),new Sprite(15,46,PATH,true),new Sprite(49,46,PATH,true)},Direction.EAST);
				
			}});
		}};
	}
	
	public NPC getByID(int index){
		return npcs.get(index);
	}
}
