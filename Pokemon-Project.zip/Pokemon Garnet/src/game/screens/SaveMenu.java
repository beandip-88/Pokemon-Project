package game.screens;

import java.awt.Graphics;
import java.awt.event.KeyEvent;

import engine.Game;
import engine.Screen;
import engine.ScreenFactory;
import game.gamePlay.TextType;
import game.gamePlay.imgs.Img;

public class SaveMenu extends Screen{
	private PromptMessageHandler prompt;
	public SaveMenu(ScreenFactory screenFactory) {
		super(screenFactory, true);
	}

	@Override
	public void onCreate() {
		prompt = new PromptMessageHandler(getScreenFactory(),"Would you like to save the game?", new String[]{"Yes","No"});
	}

	@Override
	public void onUpdate() {
		if(getKey(KeyEvent.VK_B)){
			getScreenFactory().pop();
		}
		prompt.update();
		if(prompt.getAnswer() == 0){
			save();
		}
	}
	
	private void save(){
		getScreenFactory().showScreen(new Speech(getScreenFactory(),"Save successful.",TextType.GREY));
	}

	@Override
	public void onDraw(Graphics g) {
		if(this.viewUnder){
			if(this.position != 0){
				getScreenFactory().getScreenFromTop(this.position-2).onDraw(g);
			}
		}
		prompt.draw(g);
	}

}
