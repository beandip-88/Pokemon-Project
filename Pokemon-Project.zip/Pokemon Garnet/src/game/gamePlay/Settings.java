package game.gamePlay;

import java.util.Scanner;

import engine.Game;

import java.util.ArrayList;

@SuppressWarnings("unused")
public class Settings {
	// Gameplay constants (read from file)
	public static int TEXT_SPEED = 0;
	public static FrameType FRAME = FrameType.FRAME1;
	// Pause menu arrayList
	public static ArrayList<String> pauseItems;
	
	@SuppressWarnings("serial")
	public static void init(Game game){
		pauseItems = new ArrayList<String>(){{
			add("Bag");
			add(game.getPlayer().getName());
			add("Save");
			add("Option");
			add("Exit");
		}};
		game.getPlayer().addPokemon(new Pokemon(game.getScreenFactory(),1,1));
	}
	
	public static void obtainPokemon(){
		pauseItems.add(0, "Pokemon");
	}
	
	public static void obtainPokedex(){
		pauseItems.add(0, "Pokedex");
	}
}
