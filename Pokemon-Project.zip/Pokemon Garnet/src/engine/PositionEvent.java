package engine;

public class PositionEvent extends Event{
	private int x;
	private int y;
	private boolean loopPreventer = false;
	private boolean retVal = false;
	public PositionEvent(int x, int y){
		super();
		this.x = x;
		this.y = y;
	}
	
	public boolean check(){
		retVal = false;
		if(Game.player.getCurrentNPCState().getX() != x || Game.player.getCurrentNPCState().getY() != y){
			loopPreventer = false;
			return false;
		}
		if(Game.player.getCurrentNPCState().getX() == x && Game.player.getCurrentNPCState().getY() == y){
			if(loopPreventer){
				retVal = false;
				
			}else{
				retVal = true;
				loopPreventer = true;
			}
		}
		return retVal;
	}
}
