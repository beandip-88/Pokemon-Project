package engine;

import java.io.*;
import java.util.ArrayList;

import game.gamePlay.npc.NPC;

public class MapInfo implements Serializable{
	private String[][] map;
	private static final long serialVersionUID = 3034568760561410165L;
	private SuperTile[][] tiles;
	public MapInfo(){
		
	}
	
	public int getHeight(){
		return map.length;
	}
	
	public int getWidth(){
		return map[0].length;
	}
	
	public String getStringAt(int row, int column){
		return map[row][column];
	}
	
	public int aLen(){
		return map.length;
	}
	
	public int bLen(int r){
		return map[r].length;
	}
	
	public void init(){
		tiles = new SuperTile[100][100];
	}
	
	public void setTileAt(int a, int b, SuperTile s){
		tiles[a][b] = s;
	}
	
	public SuperTile getTileAt(int a, int b){
		return tiles[a][b];
	}
}
