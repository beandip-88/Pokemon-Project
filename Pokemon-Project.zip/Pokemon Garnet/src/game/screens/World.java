package game.screens;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import engine.Game;
import engine.maps.Map;
import engine.MapInfo;
import engine.MapLoader;
import engine.Point;
import engine.Screen;
import engine.ScreenFactory;
import engine.Walkable;
import game.gamePlay.TextType;
import game.gamePlay.imgs.Img;
import game.gamePlay.npc.Direction;
import game.gamePlay.npc.GeneralNPC;
import game.gamePlay.npc.NPC;
import game.gamePlay.npc.PlayerWalk;
import game.gamePlay.npc.Sign;
import game.gamePlay.playerInfo.Player;

public class World extends Screen{
	private Player player;
	private Map map;
	private boolean[][] spacement; // LOL n00b this is for NPC's
	private int moveTimer = 0;
	public World(ScreenFactory screenFactory, String path, Player p) {
		super(screenFactory, false);
		this.map = getScreenFactory().getGame().getContainer().getMap(path);
		for(int a = 0; a< 100; a++){
			for(int b = 0; b< 100; b++){
				map.setTileAt(b,a, getScreenFactory().getGame().getTiles().getTile("src\\files\\tiles\\"+map.getStringAt(a, b)));
			}
		}
		this.player = screenFactory.getGame().getPlayer();
		map.add(new Point(10,10),player.getCurrentNPCState());
		spacement = new boolean[map.height()][map.width()];
	}

	@Override
	public void onCreate() {
		
	}

	@Override
	public void onUpdate() {
		moveTimer++;
		for(int a = 0; a < map.getTimers().size();a++){
			map.getTimers().set(a, map.getTimers().get(a).intValue()+1);
		}
		for(int a = 0; a < spacement.length;a++){
			for(int b = 0; b < spacement[a].length;b++){
				spacement[a][b] = true;
			}
		}
		for(int a = 0; a < map.pointLen(); a++){
			Point[] duty = map.getNPC(a).areaTaken();
				for(int b = 0; b < duty.length; b++){
					try{
						spacement[duty[b].getX()][duty[b].getY()] = false;
					}catch(ArrayIndexOutOfBoundsException ar){}
					}
		}
		if(player.getCurrentNPCState().getCanWalk()){
			if(player.getCurrentNPCState() instanceof PlayerWalk){			
				for(int a = 0; a < 4; a++){
					player.getPlayerWalk().setDir(Direction.getDirection(a), false, true);
				}
				if(getKeyConst(KeyEvent.VK_UP)){
					player.getPlayerWalk().up(player.getPlayerWalk(), spacement, moveTimer, map);
					moveTimer = 0;
				}else if(getKeyConst(KeyEvent.VK_DOWN)){
					player.getPlayerWalk().down(player.getPlayerWalk(), spacement, moveTimer, map);
					moveTimer = 0;
				}else if(getKeyConst(KeyEvent.VK_RIGHT)){
					player.getPlayerWalk().right(player.getPlayerWalk(), spacement, moveTimer, map);
					moveTimer = 0;
				}else if(getKeyConst(KeyEvent.VK_LEFT)){
					player.getPlayerWalk().left(player.getPlayerWalk(), spacement, moveTimer, map);
					moveTimer = 0;
				}else if(getKey(KeyEvent.VK_A)){
					if(map.getIndex(new Point(player.getCurrentNPCState().getNextStep().getX(),player.getCurrentNPCState().getNextStep().getY()))>-1){
						getScreenFactory().showScreen(new Speech(getScreenFactory(), map.getNPC(map.getIndex(new Point(player.getCurrentNPCState().getNextStep().getX(),player.getCurrentNPCState().getNextStep().getY()))).onInterract(player.getCurrentNPCState().getCurrentDirection()),TextType.DBLUE));
					}
				}else if(getKey(KeyEvent.VK_C)){ //DELETE LATER
					// for debugging use only
					System.out.println(player.getCurrentNPCState().getNextStep());
				}else if(getKey(KeyEvent.VK_ENTER)){
					getScreenFactory().showScreen(new PauseMenu(getScreenFactory()));
				}
			}
		}
		
		for(int a = 0; a<=map.width();a++){
			for(int b = 0; b<=map.height();b++){
				if(map.getIndex(new Point(a,b))>-1){
					if(map.getNPC(map.getIndex(new Point(a,b))).updatable()){
						map.getNPC(map.getIndex(new Point(a,b))).update();
						
						if(map.getNPC(map.getIndex(new Point(a,b))).hasAI()){
							map.getNPC(map.getIndex(new Point(a,b))).getAI().onTick(spacement, map.getTimers(), map.getIndex(new Point(a,b)), map, map.getNPC(map.getIndex(new Point(a,b))));
						}
					}
				}
			}
		}
		for(int a = 0; a < map.pointLen(); a++){
			double tempX = map.getNPC(a).getX();
			double tempY = map.getNPC(a).getY();
			if(tempX%1.0!=0){
				tempX+=.5;
			}
			if(tempY%1.0!=0){
				tempY+=.5;
			}
			map.setPoint(a,new Point((int)tempX,(int)tempY));
		}
		map.mapScript();
	}

	@Override
	public void onDraw(Graphics g) {
		if(this.viewUnder){
			if(this.position != 0){
				getScreenFactory().getScreenFromTop(this.position-1).onDraw(g);;
			}
		}
		// Above lines needs to go first
		
		double localX = player.getCurrentNPCState().getX();
		double localY = player.getCurrentNPCState().getY();
		if(localX % 1 != 0){
			localX -= .5;
		}
		if(localY % 1 !=0){
			localY -= .5;
		}
		int minX = (int)localX - 8;
		int maxX = (int)localX + 8;
		int minY = (int)localY - 7;
		int maxY = (int)localY + 7;
		for(int a = minX; a <= maxX; a++){
			for(int b = minY; b <=maxY; b++){
				if(!(a<0||a>=100||b<0||b>=100)){
					getScreenFactory().getGame().getTiles().getTile("src\\files\\tiles\\"+map.getStringAt(b,a)).drawBase(g,(int)(Game.multiplier*(16*a-16*player.getCurrentNPCState().getX()+112)),(int)(Game.multiplier*(16*b-16*player.getCurrentNPCState().getY()+72)));					
				}
			}
		}
		for(int a = 0; a<map.width();a++){
			for(int b = 0; b<map.height();b++){
				try{
					if(map.getIndex(new Point(a,b))>-1&&!map.getNPC((map.getIndex(new Point(a,b)))).isPlayer()){
						if(map.getNPC(map.getIndex(new Point(a,b))).canDraw()){
							map.getNPC(map.getIndex(new Point(a,b))).drawNPC(g);
						}
					}else if(map.getIndex(new Point(a,b))>-1&&map.getNPC(map.getIndex(new Point(a,b))).isPlayer()){
						player.getCurrentNPCState().draw(g, 112*Game.multiplier, 68*Game.multiplier);
					}
				}catch(Exception e){}
			}
		}
		
	}
	
	public int getTimer(){
		return this.moveTimer;
	}
	
	public Map getMap(){
		return map;
	}
	
	public boolean[][] getSpacement(){
		return spacement;
	}
}