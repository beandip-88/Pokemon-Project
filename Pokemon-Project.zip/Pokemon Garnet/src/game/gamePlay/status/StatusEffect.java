package game.gamePlay.status;

import game.gamePlay.Pokemon;
import game.gamePlay.imgs.Img;
import game.gamePlay.move.Move;

public abstract class StatusEffect {
	Img localImg;
	String name;
	
	public StatusEffect(){}
	
	public abstract void onAttack(Move m, Pokemon user, Pokemon target);
	
	public abstract void onNextMove();
}
